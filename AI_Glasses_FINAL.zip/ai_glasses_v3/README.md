# AI Smart Assistive Glasses v2 — Setup Guide
## Professor-Compliant Architecture | Windows Server

---

## ARCHITECTURE (Professor-Approved)

```
[K66F]──UART TX (PTC15)────────────────────►[ESP32-CAM GPIO13 RX]
[K66F]◄─UART RX (PTC14)────────────────────[ESP32-CAM GPIO12 TX]
[K66F]──Ethernet──────────────────────────►[Router]
                                                │
[ESP32-CAM]──Wi-Fi────────────────────────►[Router]
                                                │
                                         [Laptop Server :8080]

FLOW:
1. K66F sends  "CAPTURE\n"  to ESP32 via UART
2. ESP32 takes photo → POSTs to server /frame
3. Server runs YOLOv8n/OCR → generates audio
4. Server returns audio_id in JSON
5. ESP32 fetches WAV from /audio/{id}
6. ESP32 forwards raw WAV bytes to K66F via UART
7. K66F drives MAX98357A via I2S → speaker plays
```

---

## STEP 1 — Python Server (Windows Laptop)

### 1.1 Install Python 3.11
Download: https://www.python.org/downloads/
✅ CHECK "Add Python to PATH" during install

### 1.2 Open Command Prompt (CMD) as Administrator

### 1.3 Install dependencies
```cmd
cd path\to\server\
pip install -r requirements.txt
```

### 1.4 Install Tesseract OCR for Windows
Download installer: https://github.com/UB-Mannheim/tesseract/wiki
- Run installer
- Install to: C:\Program Files\Tesseract-OCR\
- During install: check "Add to PATH"

Verify: open new CMD window and type:
```cmd
tesseract --version
```

### 1.5 Set your OpenAI API key
Open server.py and change:
```python
OPENAI_API_KEY = "sk-..."   # paste your key here
```

### 1.6 Find your laptop's IP address
```cmd
ipconfig
```
Look for: "IPv4 Address . . . . : 192.168.X.X"
under "Wireless LAN adapter Wi-Fi"

### 1.7 Open Windows Firewall for port 8080
```cmd
netsh advfirewall firewall add rule name="AI Glasses Server" ^
  dir=in action=allow protocol=TCP localport=8080
```

### 1.8 Run the server
```cmd
python server.py
```
Expected output:
```
==================================================
  AI Smart Assistive Glasses — Server v2
  http://0.0.0.0:8080
  Mode: object
==================================================
INFO: Loading YOLOv8n...
INFO: YOLOv8n ready ✓
INFO: Uvicorn running on http://0.0.0.0:8080
```

### 1.9 Test it works
Open browser: http://localhost:8080/status
Expected: {"status": "online", "mode": "object", ...}

---

## STEP 2 — Arduino IDE + ESP32-CAM (Windows)

### 2.1 Install Arduino IDE 2.x
Download: https://www.arduino.cc/en/software
Run installer — use all defaults

### 2.2 Add ESP32 board support
1. Open Arduino IDE
2. File → Preferences
3. "Additional boards manager URLs" — paste this:
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
4. Click OK
5. Tools → Board → Boards Manager
6. Search: esp32
7. Install: "esp32 by Espressif Systems" (version 2.x)
8. Wait for install (~5 minutes)

### 2.3 Select ESP32-CAM board
Tools → Board → ESP32 Arduino → AI Thinker ESP32-CAM

### 2.4 Edit firmware — 3 values to change
Open esp32_cam_firmware.ino:
```cpp
const char* WIFI_SSID     = "YourNetworkName";   // line ~22
const char* WIFI_PASSWORD = "YourPassword";       // line ~23
const char* SERVER_IP     = "192.168.1.100";      // line ~27 ← your laptop IP
```

### 2.5 Wire FTDI programmer to flash ESP32-CAM

```
FTDI Programmer    ESP32-CAM
─────────────────────────────
GND           →   GND
5V            →   5V
TX            →   U0R (GPIO3)
RX            →   U0T (GPIO1)

IMPORTANT: Also connect:
GPIO 0        →   GND   ← enables flash mode
```

### 2.6 Flash steps
1. Make GPIO0-GND connection
2. Connect FTDI to PC via USB
3. Select port: Tools → Port → COM? (whichever appears)
4. Click Upload (→ arrow button)
5. When you see "Connecting........" → disconnect GPIO0 from GND
6. Upload completes
7. Press RESET button on ESP32-CAM
8. Open Serial Monitor (Tools → Serial Monitor → 115200 baud)

Expected output:
```
============================================
  AI Glasses — ESP32-CAM  (Wi-Fi Bridge)
  Role: Capture + Transmit ONLY
============================================
Camera init... OK
Wi-Fi connecting...OK — IP: 192.168.1.105
Server reachable ✓
Waiting for commands from K66F...
```

---

## STEP 3 — Mbed Studio + K66F (Windows)

### 3.1 Install Mbed Studio
Download: https://os.mbed.com/studio/
Run installer — use all defaults

### 3.2 Create project
1. Open Mbed Studio
2. File → New Program
3. Target board: FRDM-K66F
4. Example: "Blinky" (just to start)
5. Replace main.cpp content with our main.cpp
6. Replace/add mbed_app.json

### 3.3 Change server IP
Open main.cpp:
```cpp
#define SERVER_IP   "192.168.1.100"   // ← your laptop IP
```

### 3.4 Build
Click the hammer (Build) button
Wait for: "Build succeeded"

### 3.5 Flash to K66F
1. Connect K66F to PC via USB (micro-USB)
2. K66F appears as USB drive named "FRDM-K66F"
3. In Mbed Studio: Run → Program Device
   OR drag the .bin file onto the FRDM-K66F drive
4. Wait for LED flashing to stop
5. Press RESET button

### 3.6 Monitor output
In Mbed Studio: View → Serial Monitor → 115200 baud
Expected:
```
=============================================
  AI Smart Assistive Glasses — K66F v2
=============================================
Ethernet (DHCP)... OK — 192.168.1.102
MPU6050 init... OK
I2S (MAX98357A)... OK
All systems ready — Mode: OBJECT MODE
```

---

## WIRING DIAGRAM — Complete

### UART: K66F ↔ ESP32-CAM
```
K66F Pin              Wire      ESP32-CAM Pin
──────────────────────────────────────────────
D1 / PTD3 (UART TX)  ────────► U0R / GPIO3 (RX)
D0 / PTD2 (UART RX)  ◄──────── U0T / GPIO1 (TX)
GND                  ──────────GND
```
⚠️  BOTH boards are 3.3V logic — direct connection, NO level shifter needed
⚠️  GPIO1 and GPIO3 on ESP32-CAM are shared with USB/FTDI serial
    DISCONNECT K66F wires before flashing ESP32-CAM
    RECONNECT after flashing, then press RESET

### I2C: K66F ↔ MPU6050
```
K66F            MPU6050
───────────────────────
PTB1 (SDA) ──── SDA
PTB0 (SCL) ──── SCL
3.3V       ──── VCC
GND        ──── GND
GND        ──── AD0  (sets address to 0x68)
```

### I2S: K66F ↔ MAX98357A
```
K66F              MAX98357A
─────────────────────────────
PTC6 (BCLK)  ──── BCLK
PTC7 (FS/LR) ──── LRC
PTC5 (TXD0)  ──── DIN
3.3V         ──── VDD
GND          ──── GND
(float)      ──── GAIN   = 9dB
(float)      ──── SD     = always on
```

### Speaker/Earbud
```
MAX98357A     Speaker (8Ω)
─────────────────────────
OUT+  ──────── +
OUT-  ──────── -
```

### Buttons (Mode, Repeat, SOS)
```
Each button wired the same way:

K66F Pin ──┬──── Button ──── GND
           │
          10KΩ
           │
          3.3V
```
- Mode   → PTA1
- Repeat → PTA2
- SOS    → PTD0

### Network
```
K66F RJ45 ──── Ethernet cable ──── Router/Switch
Laptop ──────── Wi-Fi or Ethernet ─ Same Router
ESP32-CAM ────── Wi-Fi ──────────── Same Router
```
All three devices MUST be on the SAME network

---

## DEMO SCRIPT

### Say this to the panel:

**Object Mode:**
"The K66F sends a CAPTURE command to the ESP32-CAM over UART.
The ESP32-CAM takes a photo and uploads it to our AI server.
The server runs YOLOv8n — it detects stairs —
and generates a spoken alert.
The audio comes back to the ESP32-CAM as raw bytes,
which it passes straight through to the K66F via UART.
The K66F plays it through the MAX98357A amplifier."
→ [Demo shows speaker saying "Warning! Stairs detected"]

**Mode Change:**
"Pressing Mode cycles Object → Text → Quiet.
The K66F sends the mode command directly to the server over Ethernet."
→ [Press button — hear "Text reading mode"]

**Text Mode:**
"In Text Mode the server runs Tesseract OCR instead of YOLO."
→ [Hold sign to camera — hear text read aloud]

**Fall Detection:**
"The MPU6050 runs a two-phase fall detection algorithm at 100Hz
entirely on the K66F — completely local, sub-second response."
→ [Shake K66F — hear "Fall detected. Are you okay?"]
→ [Press Repeat — hear "Fall alert cancelled"]

**SOS:**
"Hold SOS 3 seconds — short press is ignored for safety."
→ [Hold 3s — hear "S.O.S. triggered. Help is being notified"]

---

## TROUBLESHOOTING

| Problem | Fix |
|---------|-----|
| Server won't start | Run CMD as Administrator |
| Tesseract not found | Add C:\Program Files\Tesseract-OCR to PATH |
| ESP32-CAM won't flash | Check GPIO0 is connected to GND during flash |
| ESP32 can't reach server | Check Windows Firewall — allow port 8080 |
| K66F Ethernet fails | Check Ethernet cable; try different router port |
| No audio from speaker | Check MAX98357A wiring (BCLK/LRC/DIN) |
| UART not working | Check TX→RX cross-connection; check shared GND |
| YOLOv8 slow | Normal on CPU — 1-2s is expected, meets requirement |
