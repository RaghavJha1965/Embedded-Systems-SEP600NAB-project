/*
 * =============================================================
 *   AI SMART ASSISTIVE GLASSES — FRDM-K66F CONTROLLER v2
 * =============================================================
 *   Board: NXP FRDM-K66F (ARM Cortex-M4F @ 180 MHz)
 *   RTOS:  mbed OS 6
 *
 *   PROFESSOR'S RULES — strictly followed:
 *   ✅ K66F triggers ESP32-CAM capture via UART
 *   ✅ K66F receives raw audio bytes from ESP32 via UART
 *   ✅ K66F drives MAX98357A I2S amplifier for audio output
 *   ✅ K66F sends mode/event commands to server via Ethernet
 *   ✅ K66F handles all buttons, IMU, state machine
 *
 *   Architecture:
 *   ─────────────────────────────────────────────
 *   [Mode/SOS/Repeat Buttons] → K66F
 *   [MPU6050 IMU]             → K66F  (fall detect)
 *   K66F ──UART──→ ESP32-CAM  (trigger capture)
 *   ESP32-CAM ──Wi-Fi──→ Server (send image)
 *   Server ──Wi-Fi──→ ESP32-CAM (return audio)
 *   ESP32-CAM ──UART──→ K66F  (raw audio bytes)
 *   K66F ──I2S──→ MAX98357A → Speaker
 *   K66F ──Ethernet──→ Server (mode/event commands)
 *
 *   Wiring:
 *   ─────────────────────────────────────────────
 *   K66F D1  / PTD3 (UART TX) → ESP32-CAM U0R (GPIO3, RX)
 *   K66F D0  / PTD2 (UART RX) ← ESP32-CAM U0T (GPIO1, TX)
 *   K66F GND                  → ESP32-CAM GND
 *   ⚠️  Disconnect UART wires when flashing ESP32-CAM!
 *   Mode Btn   → PTA1  + 10K pull-up to 3.3V
 *   Repeat Btn → PTA2  + 10K pull-up to 3.3V
 *   SOS Btn    → PTD0  + 10K pull-up to 3.3V
 *   MPU6050 SDA → PTB1 (I2C0_SDA)
 *   MPU6050 SCL → PTB0 (I2C0_SCL)
 *   MAX98357A BCLK → PTC6  (I2S0_TX_BCLK)
 *   MAX98357A LRC  → PTC7  (I2S0_TX_FS)
 *   MAX98357A DIN  → PTC5  (I2S0_TXD0)
 * =============================================================
 */

#include "mbed.h"
#include "EthernetInterface.h"

// ─── Server Config ────────────────────────────────────────────────
#define SERVER_IP     "192.168.1.100"   // !! CHANGE THIS !!
#define SERVER_PORT   8080

// ─── Pin Definitions ─────────────────────────────────────────────
#define PIN_BTN_MODE    PTA1
#define PIN_BTN_REPEAT  PTA2
#define PIN_BTN_SOS     PTD0
#define PIN_LED_GREEN   LED1
#define PIN_LED_RED     LED2
#define PIN_LED_BLUE    LED3

// UART to ESP32-CAM
// K66F D1 = PTD3 = UART0_TX  → ESP32-CAM U0R (GPIO3, RX)
// K66F D0 = PTD2 = UART0_RX  ← ESP32-CAM U0T (GPIO1, TX)
#define UART_ESP32_TX   PTD3    // K66F D1 → ESP32 U0R
#define UART_ESP32_RX   PTD2    // K66F D0 ← ESP32 U0T
#define UART_BAUD       115200

// I2C to MPU6050
#define IMU_SDA         PTB1
#define IMU_SCL         PTB0
#define MPU6050_ADDR    0x68

// I2S to MAX98357A (K66F SAI0)
// These are the K66F's dedicated I2S pins — no choice here
#define I2S_BCLK        PTC6
#define I2S_FS          PTC7
#define I2S_TXD         PTC5

// ─── Constants ───────────────────────────────────────────────────
#define SOS_HOLD_MS           3000
#define FALL_FREEFALL_G       0.3f
#define FALL_IMPACT_G         2.5f
#define FALL_FREEFALL_MS      80
#define FALL_IMPACT_WINDOW_MS 500
#define FALL_CANCEL_MS        5000
#define IMU_SAMPLE_MS         10      // 100 Hz = 10ms per sample
#define HEARTBEAT_MS          5000
#define CAPTURE_INTERVAL_MS   1000    // Auto-capture every 1s in Object mode
#define AUDIO_SAMPLE_RATE     16000   // 16kHz
#define AUDIO_BIT_DEPTH       16      // 16-bit
#define MAX_AUDIO_BUF         65536   // 64KB

// ─── System Modes ────────────────────────────────────────────────
enum class Mode { OBJECT = 0, TEXT = 1, QUIET = 2 };
const char* MODE_NAMES[]   = { "object", "text", "quiet" };
const char* MODE_LABELS[]  = { "OBJECT MODE", "TEXT MODE", "QUIET MODE" };

// ─── Global State ────────────────────────────────────────────────
volatile Mode    currentMode         = Mode::OBJECT;
volatile bool    esp32Ready          = false;
volatile bool    fallPhase1Active    = false;
volatile uint32_t fallPhase1StartMs  = 0;
volatile bool    fallConfirmPending  = false;
volatile uint32_t fallConfirmStartMs = 0;
volatile bool    sosPressActive      = false;
volatile uint32_t sosPressStartMs    = 0;

uint8_t audioBuffer[MAX_AUDIO_BUF];

// ─── Hardware ────────────────────────────────────────────────────
EthernetInterface eth;
I2C               imuI2C(IMU_SDA, IMU_SCL);
RawSerial         esp32Serial(UART_ESP32_TX, UART_ESP32_RX, UART_BAUD);

InterruptIn       btnMode(PIN_BTN_MODE, PullUp);
InterruptIn       btnRepeat(PIN_BTN_REPEAT, PullUp);
InterruptIn       btnSOS(PIN_BTN_SOS, PullUp);

DigitalOut        ledGreen(PIN_LED_GREEN, 1);
DigitalOut        ledRed(PIN_LED_RED, 1);
DigitalOut        ledBlue(PIN_LED_BLUE, 1);

// ─── Threads ─────────────────────────────────────────────────────
Thread captureThread(osPriorityNormal, 4096);
Thread imuThread(osPriorityHigh, 2048);
Thread heartbeatThread(osPriorityLow, 2048);

// ─── Event Flags ─────────────────────────────────────────────────
EventFlags events;
#define EVT_CAPTURE      0x01
#define EVT_DESCRIBE     0x02
#define EVT_REPEAT       0x04
#define EVT_SOS          0x08
#define EVT_FALL         0x10
#define EVT_MODE_CHANGE  0x20

Mutex httpMutex;
Mutex uartMutex;

// ─── Forward Declarations ────────────────────────────────────────
void     initEthernet();
void     initIMU();
void     initI2S();
void     captureTask();
void     imuTask();
void     heartbeatTask();
void     onBtnModePress();
void     onBtnRepeatPress();
void     onBtnSOSPress();
void     onBtnSOSRelease();
void     cycleMode();
void     sendToESP32(const char* cmd);
bool     receiveAudioFromESP32();
void     playAudio(uint8_t* buf, int len);
bool     httpPost(const char* endpoint, const char* body = nullptr);
bool     httpGet(const char* endpoint, char* outBuf, int bufLen);
float    imuGetMagnitude();
void     blinkLED(DigitalOut& led, int n, int ms);
void     setLEDMode(Mode m);

// ─── main ─────────────────────────────────────────────────────────
int main() {
    printf("\n=============================================\n");
    printf("  AI Smart Assistive Glasses — K66F v2\n");
    printf("  mbed OS 6 | ARM Cortex-M4F @ 180 MHz\n");
    printf("=============================================\n");

    // Button interrupts
    btnMode.fall(callback(onBtnModePress));
    btnRepeat.fall(callback(onBtnRepeatPress));
    btnSOS.fall(callback(onBtnSOSPress));
    btnSOS.rise(callback(onBtnSOSRelease));

    // Init peripherals
    initEthernet();
    initIMU();
    initI2S();

    // Start threads
    captureThread.start(captureTask);
    imuThread.start(imuTask);
    heartbeatThread.start(heartbeatTask);

    printf("All systems ready — Mode: %s\n\n", MODE_LABELS[(int)currentMode]);
    setLEDMode(currentMode);

    // ── Main event loop ──────────────────────────────────────────
    while (true) {
        uint32_t evt = events.wait_any(
            EVT_CAPTURE | EVT_DESCRIBE | EVT_REPEAT |
            EVT_SOS     | EVT_FALL     | EVT_MODE_CHANGE,
            osWaitForever
        );

        // ── Mode button ──
        if (evt & EVT_MODE_CHANGE) {
            cycleMode();
        }

        // ── Repeat button ──
        if (evt & EVT_REPEAT) {
            if (fallConfirmPending) {
                // Cancel fall event
                fallConfirmPending = false;
                printf("Fall CANCELLED by user\n");
                httpPost("/event/cancel_fall");
                blinkLED(ledGreen, 2, 150);
            } else {
                // Request repeat audio from server
                printf("Repeat — requesting /repeat from server\n");
                char resp[512];
                httpGet("/repeat", resp, sizeof(resp));
                // Audio will be queued server-side; capture task will fetch it
            }
        }

        // ── Describe (long press handled in capture task) ──
        if (evt & EVT_DESCRIBE) {
            printf("Describe triggered — sending DESCRIBE to ESP32\n");
            uartMutex.lock();
            sendToESP32("DESCRIBE\n");
            bool gotAudio = receiveAudioFromESP32();
            if (gotAudio) playAudio(audioBuffer, MAX_AUDIO_BUF);
            uartMutex.unlock();
        }

        // ── SOS ──
        if (evt & EVT_SOS) {
            printf("!!! SOS TRIGGERED !!!\n");
            ledRed  = 0;   // Red LED on
            httpPost("/event/sos");
            // Fetch and play confirmation audio
            char resp[512];
            httpGet("/audio/next", resp, sizeof(resp));
            ThisThread::sleep_for(3000ms);
            ledRed = 1;
        }

        // ── Fall ──
        if (evt & EVT_FALL) {
            printf("!!! FALL DETECTED !!!\n");
            blinkLED(ledRed, 6, 150);
            httpPost("/event/fall");
            fallConfirmPending = true;
            fallConfirmStartMs = Kernel::get_ms_count();

            // Wait for 5s cancel window
            ThisThread::sleep_for(FALL_CANCEL_MS);
            if (fallConfirmPending) {
                printf("Fall not cancelled — escalating\n");
                fallConfirmPending = false;
                // Future: trigger SMS/caregiver alert
            }
        }
    }
}

// ─── Capture Task ────────────────────────────────────────────────
// Runs continuously — sends CAPTURE to ESP32 at regular interval
void captureTask() {
    printf("Capture task started\n");

    // Wait for ESP32 to signal ready
    while (!esp32Ready) {
        if (esp32Serial.readable()) {
            char line[32] = {0};
            int i = 0;
            while (esp32Serial.readable() && i < 31) {
                char c = esp32Serial.getc();
                if (c == '\n') break;
                line[i++] = c;
            }
            if (strcmp(line, "READY") == 0) {
                esp32Ready = true;
                printf("ESP32-CAM is READY\n");
            }
        }
        ThisThread::sleep_for(100ms);
    }

    while (true) {
        // Only send CAPTURE in Object or Text mode — not Quiet
        if (currentMode == Mode::OBJECT || currentMode == Mode::TEXT) {
            uartMutex.lock();

            // Send capture command to ESP32
            sendToESP32("CAPTURE\n");

            // Receive audio bytes from ESP32 (raw passthrough from server)
            bool gotAudio = receiveAudioFromESP32();

            if (gotAudio) {
                playAudio(audioBuffer, MAX_AUDIO_BUF);
            }

            uartMutex.unlock();
        }

        ThisThread::sleep_for(CAPTURE_INTERVAL_MS);
    }
}

// ─── Receive Audio from ESP32 via UART ───────────────────────────
bool receiveAudioFromESP32() {
    // Read response header from ESP32
    char line[64] = {0};
    int  i = 0;
    unsigned long start = Kernel::get_ms_count();

    // Wait up to 8 seconds for response (server processing time)
    while ((Kernel::get_ms_count() - start) < 8000) {
        if (esp32Serial.readable()) {
            char c = esp32Serial.getc();
            if (c == '\n') break;
            if (c != '\r' && i < 63) line[i++] = c;
        }
    }

    printf("ESP32 response: '%s'\n", line);

    if (strcmp(line, "NO_AUDIO") == 0) {
        return false;
    }

    if (strncmp(line, "ERROR:", 6) == 0) {
        printf("ESP32 error: %s\n", line + 6);
        return false;
    }

    if (strncmp(line, "AUDIO_START:", 12) == 0) {
        // Parse audio byte count
        int audioLen = atoi(line + 12);
        printf("Receiving %d audio bytes from ESP32...\n", audioLen);

        if (audioLen <= 0 || audioLen > MAX_AUDIO_BUF) {
            printf("Invalid audio length: %d\n", audioLen);
            return false;
        }

        // Read raw audio bytes from UART
        int received = 0;
        start = Kernel::get_ms_count();

        while (received < audioLen && (Kernel::get_ms_count() - start) < 10000) {
            if (esp32Serial.readable()) {
                audioBuffer[received++] = esp32Serial.getc();
            }
        }

        printf("Received %d/%d audio bytes\n", received, audioLen);

        // Read AUDIO_END marker
        char endLine[16] = {0};
        i = 0;
        start = Kernel::get_ms_count();
        while ((Kernel::get_ms_count() - start) < 1000) {
            if (esp32Serial.readable()) {
                char c = esp32Serial.getc();
                if (c == '\n') break;
                if (c != '\r' && i < 15) endLine[i++] = c;
            }
        }
        printf("End marker: '%s'\n", endLine);

        return received > 44;   // Must have at least WAV header
    }

    return false;
}

// ─── Play Audio via I2S → MAX98357A ──────────────────────────────
void playAudio(uint8_t* buf, int bufSize) {
    // Skip 44-byte WAV header to get to raw PCM data
    if (bufSize <= 44) return;

    int16_t* pcm      = (int16_t*)(buf + 44);
    int      samples  = (bufSize - 44) / 2;

    printf("Playing %d PCM samples at %d Hz\n", samples, AUDIO_SAMPLE_RATE);

    // Write to I2S peripheral
    // K66F SAI (I2S) driver — write 16-bit samples
    // The SAI peripheral clocks out samples at 16kHz automatically
    // after configuration in initI2S()

    // Direct register write approach for K66F SAI0:
    volatile uint32_t* SAI0_TDR0 = (volatile uint32_t*)0x4002F020;  // SAI0 Transmit Data Register
    volatile uint32_t* SAI0_TCSR = (volatile uint32_t*)0x4002F000;  // SAI0 Tx Control/Status

    for (int i = 0; i < samples; i++) {
        // Wait for TX FIFO to have space
        while (!(*SAI0_TCSR & (1 << 20))) { /* wait for FRDE */ }
        *SAI0_TDR0 = (uint32_t)pcm[i] << 16;   // Left-justify 16-bit in 32-bit slot
    }

    printf("Audio playback complete\n");
}

// ─── IMU Task — 100 Hz Fall Detection ───────────────────────────
void imuTask() {
    printf("IMU task started at 100 Hz\n");

    while (true) {
        float mag = imuGetMagnitude();

        // ── Phase 1: Free-fall ──
        if (!fallPhase1Active) {
            if (mag < FALL_FREEFALL_G) {
                fallPhase1Active  = true;
                fallPhase1StartMs = Kernel::get_ms_count();
            }
        } else {
            uint32_t elapsed = Kernel::get_ms_count() - fallPhase1StartMs;

            if (mag >= FALL_FREEFALL_G) {
                // Acceleration returned — did Phase 1 last long enough?
                if (elapsed >= FALL_FREEFALL_MS) {
                    printf("Phase 1 confirmed (%lu ms < 0.3g)\n", elapsed);
                    // Now watch for Phase 2 impact
                    uint32_t p2Start = Kernel::get_ms_count();
                    bool phase2 = false;

                    while ((Kernel::get_ms_count() - p2Start) < FALL_IMPACT_WINDOW_MS) {
                        float impactMag = imuGetMagnitude();
                        if (impactMag >= FALL_IMPACT_G) {
                            printf("Phase 2 confirmed! Impact=%.2fg\n", impactMag);
                            phase2 = true;
                            events.set(EVT_FALL);
                            break;
                        }
                        ThisThread::sleep_for(IMU_SAMPLE_MS);
                    }

                    if (!phase2) printf("Phase 2 not detected — not a fall\n");
                }
                fallPhase1Active = false;
            }
        }

        ThisThread::sleep_for(IMU_SAMPLE_MS);
    }
}

// ─── Heartbeat Task ──────────────────────────────────────────────
void heartbeatTask() {
    printf("Heartbeat task started\n");

    while (true) {
        char resp[256];
        bool alive = httpGet("/status", resp, sizeof(resp));
        if (!alive) printf("Server UNREACHABLE\n");
        else        ledBlue = !ledBlue;   // Toggle blue LED
        ThisThread::sleep_for(HEARTBEAT_MS);
    }
}

// ─── Button Callbacks ────────────────────────────────────────────
void onBtnModePress() {
    static uint32_t lastMs = 0;
    uint32_t now = Kernel::get_ms_count();
    if (now - lastMs < 50) return;
    lastMs = now;
    events.set(EVT_MODE_CHANGE);
}

void onBtnRepeatPress() {
    static uint32_t lastMs = 0;
    uint32_t now = Kernel::get_ms_count();
    if (now - lastMs < 50) return;
    lastMs = now;
    events.set(EVT_REPEAT);
}

void onBtnSOSPress() {
    sosPressActive  = true;
    sosPressStartMs = Kernel::get_ms_count();
}

void onBtnSOSRelease() {
    if (!sosPressActive) return;
    uint32_t held = Kernel::get_ms_count() - sosPressStartMs;
    sosPressActive = false;
    if (held >= SOS_HOLD_MS) {
        printf("SOS held %lu ms — triggering!\n", held);
        events.set(EVT_SOS);
    } else {
        printf("SOS released early (%lu ms) — ignored\n", held);
    }
}

// ─── Cycle Mode ──────────────────────────────────────────────────
void cycleMode() {
    currentMode = (Mode)(((int)currentMode + 1) % 3);
    printf("Mode → %s\n", MODE_LABELS[(int)currentMode]);
    setLEDMode(currentMode);

    // Notify server
    char body[48];
    snprintf(body, sizeof(body), "{\"mode\":\"%s\"}", MODE_NAMES[(int)currentMode]);
    httpPost("/mode", body);
}

// ─── MPU6050 Init ─────────────────────────────────────────────────
void initIMU() {
    printf("MPU6050 init... ");
    char cmd[2];

    // Wake up
    cmd[0] = 0x6B; cmd[1] = 0x00;
    imuI2C.write(MPU6050_ADDR << 1, cmd, 2);
    ThisThread::sleep_for(10ms);

    // Accel range ±8g → sensitivity 4096 LSB/g
    cmd[0] = 0x1C; cmd[1] = 0x10;
    imuI2C.write(MPU6050_ADDR << 1, cmd, 2);

    // Sample rate = 100 Hz
    cmd[0] = 0x19; cmd[1] = 9;
    imuI2C.write(MPU6050_ADDR << 1, cmd, 2);

    printf("OK\n");
}

// ─── IMU Read Acceleration Magnitude ────────────────────────────
float imuGetMagnitude() {
    char reg = 0x3B;
    char raw[6];
    imuI2C.write(MPU6050_ADDR << 1, &reg, 1, true);
    imuI2C.read(MPU6050_ADDR << 1, raw, 6);

    int16_t ax = (int16_t)((raw[0] << 8) | raw[1]);
    int16_t ay = (int16_t)((raw[2] << 8) | raw[3]);
    int16_t az = (int16_t)((raw[4] << 8) | raw[5]);

    float gx = ax / 4096.0f;
    float gy = ay / 4096.0f;
    float gz = az / 4096.0f;
    return sqrtf(gx*gx + gy*gy + gz*gz);
}

// ─── Ethernet Init ────────────────────────────────────────────────
void initEthernet() {
    printf("Ethernet (DHCP)... ");
    eth.set_dhcp(true);
    nsapi_error_t err = eth.connect();
    if (err != NSAPI_ERROR_OK) {
        printf("FAILED (%d)\n", err);
    } else {
        SocketAddress ip;
        eth.get_ip_address(&ip);
        printf("OK — %s\n", ip.get_ip_address());
    }
}

// ─── I2S Init ────────────────────────────────────────────────────
void initI2S() {
    printf("I2S (MAX98357A)... ");
    // K66F SAI0 — 16kHz, 16-bit, Philips I2S
    // Configure SAI0 clock: 16kHz × 16-bit × 2 = 512 kHz BCLK
    // MCG provides ~12.288 MHz to SAI → divider = 24 → 512 kHz BCLK ✓

    // SAI0 base address
    volatile uint32_t* SAI0_TCSR  = (volatile uint32_t*)0x4002F000;
    volatile uint32_t* SAI0_TCR1  = (volatile uint32_t*)0x4002F004;
    volatile uint32_t* SAI0_TCR2  = (volatile uint32_t*)0x4002F008;
    volatile uint32_t* SAI0_TCR3  = (volatile uint32_t*)0x4002F00C;
    volatile uint32_t* SAI0_TCR4  = (volatile uint32_t*)0x4002F010;
    volatile uint32_t* SAI0_TCR5  = (volatile uint32_t*)0x4002F014;

    // Enable SAI0 clock gate (SIM_SCGC6 bit 15)
    volatile uint32_t* SIM_SCGC6  = (volatile uint32_t*)0x4004803C;
    *SIM_SCGC6 |= (1 << 15);

    // Transmitter: software reset
    *SAI0_TCSR = (1 << 24);
    while (*SAI0_TCSR & (1 << 24)) {}

    // TCR2: MCLK from bus clock, divide for 16kHz
    *SAI0_TCR2 = 0x0F000000;   // MSEL=bus, DIV=15

    // TCR3: 1 channel enabled
    *SAI0_TCR3 = 0x00010000;

    // TCR4: Philips I2S, 32-bit frame, 16-bit word, MSB first
    *SAI0_TCR4 = 0x00071F1F;

    // TCR5: word bit mask
    *SAI0_TCR5 = 0x1F0F0000;

    // Enable transmitter
    *SAI0_TCSR = (1 << 31) | (1 << 28);

    printf("OK\n");
}

// ─── HTTP Helpers ─────────────────────────────────────────────────
bool httpPost(const char* endpoint, const char* body) {
    httpMutex.lock();

    TCPSocket sock;
    sock.open(&eth);
    sock.set_timeout(5000);

    SocketAddress addr;
    eth.get_hostbyname(SERVER_IP, &addr);
    addr.set_port(SERVER_PORT);

    bool success = false;
    if (sock.connect(addr) == NSAPI_ERROR_OK) {
        char req[512];
        int  bodyLen = body ? strlen(body) : 0;
        snprintf(req, sizeof(req),
            "POST %s HTTP/1.1\r\n"
            "Host: %s:%d\r\n"
            "Content-Type: application/json\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n\r\n"
            "%s",
            endpoint, SERVER_IP, SERVER_PORT,
            bodyLen, body ? body : ""
        );
        sock.send(req, strlen(req));
        char resp[128];
        int  n = sock.recv(resp, sizeof(resp)-1);
        if (n > 0) { resp[n] = 0; success = strstr(resp, "200") != nullptr; }
    }

    sock.close();
    httpMutex.unlock();
    return success;
}

bool httpGet(const char* endpoint, char* outBuf, int bufLen) {
    httpMutex.lock();

    TCPSocket sock;
    sock.open(&eth);
    sock.set_timeout(5000);

    SocketAddress addr;
    eth.get_hostbyname(SERVER_IP, &addr);
    addr.set_port(SERVER_PORT);

    bool success = false;
    if (sock.connect(addr) == NSAPI_ERROR_OK) {
        char req[256];
        snprintf(req, sizeof(req),
            "GET %s HTTP/1.1\r\nHost: %s:%d\r\nConnection: close\r\n\r\n",
            endpoint, SERVER_IP, SERVER_PORT
        );
        sock.send(req, strlen(req));

        int total = 0, n = 0;
        while ((n = sock.recv(outBuf + total, bufLen - total - 1)) > 0) total += n;
        outBuf[total] = 0;
        success = total > 0 && strstr(outBuf, "404") == nullptr;
    }

    sock.close();
    httpMutex.unlock();
    return success;
}

// ─── UART to ESP32 ───────────────────────────────────────────────
void sendToESP32(const char* cmd) {
    esp32Serial.printf("%s", cmd);
    printf("→ ESP32: %s", cmd);
}

// ─── LED Helpers ─────────────────────────────────────────────────
void blinkLED(DigitalOut& led, int n, int ms) {
    for (int i = 0; i < n; i++) {
        led = 0; ThisThread::sleep_for(ms);
        led = 1; ThisThread::sleep_for(ms);
    }
}

void setLEDMode(Mode m) {
    // Green = Object, Blue = Text, both off = Quiet
    ledGreen = (m == Mode::OBJECT) ? 0 : 1;
    ledBlue  = (m == Mode::TEXT)   ? 0 : 1;
}
