"""
=============================================================
  AI SMART ASSISTIVE GLASSES — HOME SERVER v2
=============================================================
  Layer 3: Python FastAPI Server (Windows)
  
  Architecture (Professor-compliant):
  ESP32-CAM → Wi-Fi → Server → Wi-Fi → ESP32-CAM → UART → K66F
  K66F → Ethernet → Server (mode/event commands)
  
  Run on Windows:
    pip install -r requirements.txt
    python server.py
=============================================================
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, JSONResponse
import uvicorn
import cv2
import numpy as np
import pytesseract
import threading
import time
import uuid
import os
import base64
import logging
from pathlib import Path
from pydantic import BaseModel
from typing import Optional
import openai

# ─── Windows Tesseract Path ──────────────────────────────────────
# On Windows you MUST set this path after installing Tesseract
# Download from: https://github.com/UB-Mannheim/tesseract/wiki
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# ─── Logging ─────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("server.log")
    ]
)
log = logging.getLogger("glasses")

# ─── Config ──────────────────────────────────────────────────────
OPENAI_API_KEY    = "YOUR_OPENAI_API_KEY_HERE"   # ← Replace this
AUDIO_DIR         = Path("audio_cache")
YOLO_CONFIDENCE   = 0.60
OPENAI_THRESHOLD  = 0.45
COOLDOWN_SECS     = 8
OPENAI_RATE_LIMIT = 10
MAX_AUDIO_QUEUE   = 2
PORT              = 8080

AUDIO_DIR.mkdir(exist_ok=True)
openai.api_key = OPENAI_API_KEY

# ─── Object Priority ─────────────────────────────────────────────
CRITICAL = {
    "stairs","step","curb","car","truck","bus",
    "bicycle","motorcycle","person","fire hydrant",
    "stop sign","manhole","traffic light"
}
HIGH = {
    "door","chair","dining table","bench",
    "dog","cat","horse","cow","sheep","bird"
}
MEDIUM = {
    "tv","laptop","cell phone","book","bottle",
    "cup","bowl","potted plant","clock","keyboard","mouse"
}
# Everything else = LOW (suppressed)

# ─── State ────────────────────────────────────────────────────────
class State:
    def __init__(self):
        self.mode           = "object"
        self.last_detection = "None"
        self.audio_queue    = []          # list of (audio_id, file_path)
        self.cooldowns      = {}          # {class: last_alert_time}
        self.last_openai    = 0
        self.fall_pending   = False
        self.sos_pending    = False
        self.lock           = threading.Lock()
        self.start_time     = time.time()

S = State()

# ─── TTS ─────────────────────────────────────────────────────────
tts_lock = threading.Lock()

def tts(text: str) -> Optional[str]:
    """Generate WAV from text. Returns file path."""
    try:
        with tts_lock:
            import pyttsx3
            audio_id  = str(uuid.uuid4())[:8]
            path      = AUDIO_DIR / f"audio_{audio_id}.wav"
            engine    = pyttsx3.init()
            engine.setProperty("rate", 145)
            engine.setProperty("volume", 1.0)
            # Windows: pick a clear voice
            voices = engine.getProperty("voices")
            for v in voices:
                if "zira" in v.name.lower() or "david" in v.name.lower():
                    engine.setProperty("voice", v.id)
                    break
            engine.save_to_file(text, str(path))
            engine.runAndWait()
            log.info(f"TTS: '{text}' → {path.name}")
            return str(path), audio_id
    except Exception as e:
        log.error(f"TTS error: {e}")
        return None, None

def queue_audio(text: str) -> Optional[str]:
    """Generate audio and add to queue. Returns audio_id."""
    path, audio_id = tts(text)
    if not path:
        return None
    with S.lock:
        if len(S.audio_queue) >= MAX_AUDIO_QUEUE:
            old_id, old_path = S.audio_queue.pop(0)
            try: os.remove(old_path)
            except: pass
            log.info("Queue full — dropped oldest clip")
        S.audio_queue.append((audio_id, path))
    return audio_id

def emergency_audio(text: str) -> str:
    """Emergency audio — inserted at front, bypasses queue limit."""
    path, audio_id = tts(text)
    if path:
        with S.lock:
            S.audio_queue.insert(0, (audio_id, path))
    return audio_id or ""

# ─── YOLO ─────────────────────────────────────────────────────────
log.info("Loading YOLOv8n...")
from ultralytics import YOLO
yolo = YOLO("yolov8n.pt")
log.info("YOLOv8n ready ✓")

def run_yolo(frame: np.ndarray) -> dict:
    results = yolo(frame, conf=YOLO_CONFIDENCE, verbose=False)
    detections = []
    max_conf   = 0.0
    alert_text = ""
    should_alert = False

    for r in results:
        for box in r.boxes:
            name = yolo.names[int(box.cls[0])].lower()
            conf = float(box.conf[0])
            max_conf = max(max_conf, conf)
            detections.append({"class": name, "confidence": round(conf, 2)})

            now = time.time()
            if name in CRITICAL:
                alert_text   = f"Warning! {name} detected ahead."
                should_alert = True
            elif name in HIGH:
                last = S.cooldowns.get(name, 0)
                if now - last > COOLDOWN_SECS:
                    alert_text   = f"{name.capitalize()} nearby."
                    should_alert = True
                    S.cooldowns[name] = now

    return {"detections": detections, "max_confidence": max_conf,
            "should_alert": should_alert, "alert_text": alert_text}

# ─── OpenAI Vision ────────────────────────────────────────────────
def run_vision(frame: np.ndarray) -> str:
    now = time.time()
    if now - S.last_openai < OPENAI_RATE_LIMIT:
        log.info("OpenAI rate limited")
        return ""
    try:
        S.last_openai = now
        _, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
        b64    = base64.b64encode(buf).decode()
        resp   = openai.chat.completions.create(
            model="gpt-4o",
            max_tokens=80,
            messages=[{"role":"user","content":[
                {"type":"text","text":
                    "You are an assistive AI for a visually impaired user. "
                    "Describe this scene in 1-2 sentences. Mention hazards first."},
                {"type":"image_url","image_url":{
                    "url":f"data:image/jpeg;base64,{b64}","detail":"low"}}
            ]}]
        )
        desc = resp.choices[0].message.content.strip()
        log.info(f"Vision: {desc}")
        return desc
    except Exception as e:
        log.error(f"OpenAI Vision error: {e}")
        return "Could not analyze the scene."

# ─── OCR ──────────────────────────────────────────────────────────
def run_ocr(frame: np.ndarray) -> str:
    try:
        gray   = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        thresh = cv2.adaptiveThreshold(gray, 255,
                    cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                    cv2.THRESH_BINARY, 11, 2)
        # Deskew
        coords = np.column_stack(np.where(thresh > 0))
        if len(coords) > 0:
            angle = cv2.minAreaRect(coords)[-1]
            angle = -(90 + angle) if angle < -45 else -angle
            if abs(angle) > 0.5:
                h, w = thresh.shape[:2]
                M    = cv2.getRotationMatrix2D((w//2, h//2), angle, 1.0)
                thresh = cv2.warpAffine(thresh, M, (w, h),
                            flags=cv2.INTER_CUBIC,
                            borderMode=cv2.BORDER_REPLICATE)
        # Tesseract
        data  = pytesseract.image_to_data(thresh,
                    output_type=pytesseract.Output.DICT, config="--psm 6")
        words, total_conf, count = [], 0, 0
        for i, word in enumerate(data["text"]):
            conf = int(data["conf"][i])
            if conf > 50 and word.strip():
                words.append(word)
                total_conf += conf
                count += 1
        avg_conf = total_conf / count if count else 0
        text     = " ".join(words).strip()

        if not text or avg_conf < 60:
            log.info(f"OCR low confidence ({avg_conf:.0f}%) — Vision fallback")
            return run_vision(frame) or "No text found."
        log.info(f"OCR ({avg_conf:.0f}%): {text}")
        return f"Text reads: {text}"
    except Exception as e:
        log.error(f"OCR error: {e}")
        return run_vision(frame) or "Could not read text."

# ─── FastAPI ──────────────────────────────────────────────────────
app = FastAPI(title="AI Glasses Server", version="2.0")

@app.post("/frame")
async def receive_frame(file: UploadFile = File(...)):
    """Receive JPEG from ESP32-CAM. Run inference. Queue audio."""
    data  = await file.read()
    arr   = np.frombuffer(data, np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if frame is None:
        raise HTTPException(400, "Bad image")

    log.info(f"Frame {frame.shape} | Mode: {S.mode}")

    if S.mode == "quiet":
        return JSONResponse({"status":"quiet","audio_id":None})

    if S.mode == "text":
        result   = run_ocr(frame)
        audio_id = queue_audio(result)
        S.last_detection = result
        return JSONResponse({"status":"ocr","result":result,"audio_id":audio_id})

    # Object mode
    res = run_yolo(frame)
    if res["max_confidence"] < OPENAI_THRESHOLD and res["max_confidence"] > 0:
        desc = run_vision(frame)
        if desc:
            audio_id = queue_audio(desc)
            S.last_detection = desc
            return JSONResponse({"status":"vision","result":desc,"audio_id":audio_id})

    if res["should_alert"]:
        audio_id = queue_audio(res["alert_text"])
        S.last_detection = res["alert_text"]
        return JSONResponse({"status":"alert","detections":res["detections"],
                             "alert_text":res["alert_text"],"audio_id":audio_id})

    return JSONResponse({"status":"no_alert","detections":res["detections"],"audio_id":None})


@app.post("/describe")
async def describe(file: UploadFile = File(...)):
    """On-demand GPT-4 Vision scene description."""
    data  = await file.read()
    arr   = np.frombuffer(data, np.uint8)
    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if frame is None:
        raise HTTPException(400, "Bad image")
    desc     = run_vision(frame) or "Could not describe scene."
    audio_id = queue_audio(desc)
    S.last_detection = desc
    return JSONResponse({"status":"described","result":desc,"audio_id":audio_id})


class ModeReq(BaseModel):
    mode: str

@app.post("/mode")
async def set_mode(req: ModeReq):
    """K66F changes system mode."""
    if req.mode not in {"object","text","quiet","sos"}:
        raise HTTPException(400, "Invalid mode")
    S.mode = req.mode
    log.info(f"Mode → {S.mode}")
    confirmations = {
        "object":"Object detection mode.",
        "text":  "Text reading mode.",
        "quiet": "Quiet mode. Emergency alerts still active.",
        "sos":   "S.O.S. mode activated."
    }
    audio_id = queue_audio(confirmations[req.mode])
    return JSONResponse({"status":"ok","mode":S.mode,"audio_id":audio_id})


@app.post("/event/fall")
async def fall():
    """K66F confirmed fall detection."""
    log.warning("FALL EVENT")
    S.fall_pending = True
    aid = emergency_audio("Fall detected. Are you okay? Press repeat to cancel.")
    log.warning(f"Fall logged at {time.strftime('%Y-%m-%d %H:%M:%S')}")
    return JSONResponse({"status":"acknowledged","audio_id":aid,"ts":time.time()})


@app.post("/event/cancel_fall")
async def cancel_fall():
    S.fall_pending = False
    aid = queue_audio("Fall alert cancelled.")
    return JSONResponse({"status":"cancelled","audio_id":aid})


@app.post("/event/sos")
async def sos():
    """K66F SOS button held 3 seconds."""
    log.warning("SOS EVENT")
    S.sos_pending = True
    aid = emergency_audio("S.O.S. triggered. Help is being notified.")
    log.warning(f"SOS logged at {time.strftime('%Y-%m-%d %H:%M:%S')}")
    return JSONResponse({"status":"acknowledged","audio_id":aid,"ts":time.time()})


@app.get("/audio/next")
async def audio_next():
    """K66F polls for next pending audio clip."""
    with S.lock:
        if not S.audio_queue:
            raise HTTPException(404, "No audio")
        audio_id, path = S.audio_queue.pop(0)
    if not os.path.exists(path):
        raise HTTPException(404, "File missing")
    log.info(f"Serving audio: {path}")
    return FileResponse(path, media_type="audio/wav")


@app.get("/audio/{audio_id}")
async def audio_by_id(audio_id: str):
    """Fetch audio by ID."""
    path = AUDIO_DIR / f"audio_{audio_id}.wav"
    if not path.exists():
        raise HTTPException(404, "Not found")
    return FileResponse(str(path), media_type="audio/wav")


@app.get("/repeat")
async def repeat():
    """Re-queue last detection audio."""
    if S.last_detection and S.last_detection != "None":
        aid = queue_audio(f"Repeating: {S.last_detection}")
        return JSONResponse({"status":"queued","audio_id":aid})
    return JSONResponse({"status":"nothing_to_repeat"})


@app.get("/status")
async def status():
    """Heartbeat — K66F polls every 5 seconds."""
    uptime = int(time.time() - S.start_time)
    return JSONResponse({
        "status":         "online",
        "mode":           S.mode,
        "last_detection": S.last_detection,
        "audio_queued":   len(S.audio_queue),
        "fall_pending":   S.fall_pending,
        "sos_pending":    S.sos_pending,
        "uptime":         f"{uptime//3600}h {(uptime%3600)//60}m {uptime%60}s"
    })


if __name__ == "__main__":
    log.info("=" * 50)
    log.info("  AI Smart Assistive Glasses — Server v2")
    log.info(f"  http://0.0.0.0:{PORT}")
    log.info(f"  Mode: {S.mode}")
    log.info("=" * 50)
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="info")
