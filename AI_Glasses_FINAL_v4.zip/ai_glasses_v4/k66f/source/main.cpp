/*
 * ================================================================
 *  AI SMART ASSISTIVE GLASSES — FRDM-K66F MASTER CONTROLLER
 *  MCUXpresso SDK | mbed OS 6
 * ================================================================
 *
 *  COMPLETE PIN MAP:
 *  ─────────────────────────────────────────────────────────────
 *  UART to ESP32-CAM:
 *    D1 / PTD3  → ESP32 U0R (GPIO3, RX)  [UART0 TX]
 *    D0 / PTD2  ← ESP32 U0T (GPIO1, TX)  [UART0 RX]
 *    GND        → ESP32 GND
 *    ⚠️ Disconnect before flashing ESP32
 *
 *  SPI to Arducam OV2640 — SPI2 (PTB20-23, zero conflicts):
 *    PTB20  → Arducam MOSI  [SPI2 MOSI]
 *    PTB22  ← Arducam MISO  [SPI2 MISO]
 *    PTB21  → Arducam SCK   [SPI2 SCK]
 *    PTB23  → Arducam CS    [SPI2 CS, software]
 *    3.3V   → Arducam VCC
 *    GND    → Arducam GND
 *    PTE25  → Arducam SDA   [I2C1 camera config]
 *    PTE24  → Arducam SCL   [I2C1 camera config]
 *    WHY SPI2? SPI0 (PTD0-3) conflicts with UART (PTD2/PTD3).
 *             SPI2 (PTB20-23) has zero conflicts with all other pins.
 *
 *  I2C to MPU6050 + VL53L0X sensors — I2C0 shared bus:
 *    PTB1 / A4  → SDA  [I2C0]
 *    PTB0 / A5  → SCL  [I2C0]
 *    NOTE: PTB0/1 ≠ PTB20-23 — I2C0 and SPI2 don't conflict.
 *
 *  VL53L0X XSHUT pins (PTD4-PTD7 as specified):
 *    PTD4  → VL53L0X FORWARD  XSHUT  (→ address 0x30)
 *    PTD5  → VL53L0X DOWNWARD XSHUT  (→ address 0x31)
 *    PTD6  → VL53L0X LEFT     XSHUT  (→ address 0x32)
 *    PTD7  → VL53L0X RIGHT    XSHUT  (→ address 0x33)
 *
 *  VL53L0X I2C addresses after reassignment:
 *    FORWARD  → 0x30
 *    DOWNWARD → 0x31
 *    LEFT     → 0x32
 *    RIGHT    → 0x33
 *
 *  DAC to PAM8403 amplifier:
 *    DAC0_OUT / PTE30  → PAM8403 Left IN  (analog audio)
 *    GND               → PAM8403 GND
 *    5V                → PAM8403 VDD  (needs 5V for full power)
 *    PAM8403 OUT+      → Speaker +
 *    PAM8403 OUT-      → Speaker -
 *    ⚠️ PAM8403 input is differential — tie Right IN to GND
 *       for mono operation
 *
 *  Buttons (10K pull-up to 3.3V on each):
 *    Mode   → PTA1
 *    Repeat → PTA2
 *    SOS    → PTD0
 *
 *  Ethernet:
 *    K66F built-in RJ45 → Router (same network as laptop)
 * ================================================================
 */

#include "mbed.h"
#include "EthernetInterface.h"
#include <cmath>
#include <cstring>
#include <cstdio>

// ─── Server Config ────────────────────────────────────────────────
#define SERVER_IP    "192.168.1.100"   // !! CHANGE to your laptop IP
#define SERVER_PORT  8080

// ─── UART to ESP32-CAM ───────────────────────────────────────────
#define UART_TX      PTD3   // D1 → ESP32 U0R
#define UART_RX      PTD2   // D0 ← ESP32 U0T
#define UART_BAUD    115200

// ─── SPI to Arducam OV2640 — using SPI2 (PTB20-23) ─────────────
// SPI0 is on PTD0-3 which conflicts with our UART (PTD2/PTD3)
// SPI2 on PTB20-23 has zero conflicts with any other peripheral
#define CAM_MOSI     PTB20  // SPI2 MOSI
#define CAM_MISO     PTB22  // SPI2 MISO
#define CAM_SCK      PTB21  // SPI2 SCK
#define CAM_CS       PTB23  // SPI2 CS (software-controlled)
#define CAM_I2C_SDA  PTE25  // D14 — camera register config via I2C1
#define CAM_I2C_SCL  PTE24  // D15

// ─── I2C (MPU6050 + VL53L0X shared bus) ─────────────────────────
#define IMU_SDA      PTB1   // A4  — I2C0
#define IMU_SCL      PTB0   // A5  — I2C0
// NOTE: PTB0/1 (I2C0) and PTB20-23 (SPI2) are different PTB pins — no conflict

// ─── VL53L0X XSHUT pins — PTD4/5/6/7 as requested ───────────────
#define TOF_XSHUT_FWD  PTD4  // Forward sensor  — boot first
#define TOF_XSHUT_DWN  PTD5  // Downward sensor — stair detect
#define TOF_XSHUT_LFT  PTD6  // Left sensor
#define TOF_XSHUT_RGT  PTD7  // Right sensor

// VL53L0X reassigned I2C addresses
#define TOF_ADDR_FWD   0x30
#define TOF_ADDR_DWN   0x31
#define TOF_ADDR_LFT   0x32
#define TOF_ADDR_RGT   0x33
#define TOF_DEFAULT    0x29   // Factory default — all sensors start here

// ─── DAC to PAM8403 ──────────────────────────────────────────────
#define DAC_PIN      PTE30   // DAC0_OUT

// ─── Buttons ─────────────────────────────────────────────────────
#define BTN_MODE     PTA1
#define BTN_REPEAT   PTA2
#define BTN_SOS      PTD0

// ─── LEDs ────────────────────────────────────────────────────────
#define LED_GREEN    LED1
#define LED_RED      LED2
#define LED_BLUE     LED3

// ─── Constants ───────────────────────────────────────────────────
#define SOS_HOLD_MS           3000
#define FALL_FREEFALL_G       0.3f
#define FALL_IMPACT_G         2.5f
#define FALL_FREEFALL_MS      80
#define FALL_IMPACT_WIN_MS    500
#define FALL_CANCEL_MS        5000
#define IMU_SAMPLE_MS         10       // 100 Hz
#define TOF_SAMPLE_MS         50       // 20 Hz — fast enough for walking
#define CAPTURE_INTERVAL_MS   1000     // 1 FPS camera
#define HEARTBEAT_MS          5000
#define AUDIO_SAMPLE_RATE     16000    // 16 kHz
#define MAX_AUDIO_BYTES       65536    // 64 KB
#define TOF_STAIR_MM          400      // Downward drop > 400mm = stair
#define TOF_OBSTACLE_MM       600      // Forward < 600mm = obstacle warning
#define TOF_SIDE_MM           300      // Side < 300mm = too close to wall

// ─── Arducam SPI Registers ───────────────────────────────────────
#define ARDUCHIP_TEST1    0x00
#define ARDUCHIP_FIFO     0x04
#define FIFO_CLEAR_MASK   0x01
#define FIFO_START_MASK   0x02
#define ARDUCHIP_TRIG     0x41
#define CAP_DONE_MASK     0x08
#define FIFO_SIZE1        0x42
#define FIFO_SIZE2        0x43
#define FIFO_SIZE3        0x44
#define SINGLE_FIFO_READ  0x3D
#define BURST_FIFO_READ   0x3C

// OV2640 I2C address for config
#define OV2640_I2C_ADDR   0x30

// ─── System Modes ────────────────────────────────────────────────
enum class Mode { OBJECT = 0, TEXT = 1, QUIET = 2 };
const char* MODE_NAMES[]  = { "object", "text", "quiet" };
const char* MODE_LABELS[] = { "OBJECT MODE", "TEXT MODE", "QUIET MODE" };

// ─── Global State ────────────────────────────────────────────────
volatile Mode    gMode              = Mode::OBJECT;
volatile bool    gESP32Ready        = false;
volatile bool    gFallPhase1        = false;
volatile uint32_t gFallPhase1Ms     = 0;
volatile bool    gFallConfirm       = false;
volatile uint32_t gFallConfirmMs    = 0;
volatile bool    gSOSActive         = false;
volatile uint32_t gSOSPressMs       = 0;

// Audio buffer — receives raw WAV from ESP32 via UART
uint8_t  gAudioBuf[MAX_AUDIO_BYTES];
uint32_t gAudioLen = 0;

// ─── Hardware Objects ────────────────────────────────────────────
EthernetInterface eth;
I2C               sensI2C(IMU_SDA, IMU_SCL);      // MPU6050 + VL53L0X
I2C               camI2C(CAM_I2C_SDA, CAM_I2C_SCL); // Arducam OV2640 config
SPI               camSPI(CAM_MOSI, CAM_MISO, CAM_SCK);
DigitalOut        camCS(CAM_CS, 1);               // CS active-low, start HIGH

// VL53L0X XSHUT (active-low shutdown, pull HIGH to enable)
DigitalOut        xshutFwd(TOF_XSHUT_FWD, 0);
DigitalOut        xshutDwn(TOF_XSHUT_DWN, 0);
DigitalOut        xshutLft(TOF_XSHUT_LFT, 0);
DigitalOut        xshutRgt(TOF_XSHUT_RGT, 0);

// DAC for PAM8403
AnalogOut         dacOut(DAC_PIN);

// UART to ESP32
RawSerial         espUART(UART_TX, UART_RX, UART_BAUD);

// Buttons
InterruptIn       btnMode(BTN_MODE, PullUp);
InterruptIn       btnRepeat(BTN_REPEAT, PullUp);
InterruptIn       btnSOS(BTN_SOS, PullUp);

// LEDs
DigitalOut        ledGreen(LED_GREEN, 1);
DigitalOut        ledRed(LED_RED,   1);
DigitalOut        ledBlue(LED_BLUE,  1);

// ─── Threads ─────────────────────────────────────────────────────
Thread tCapture(osPriorityNormal,   8192);
Thread tIMU(osPriorityHigh,         2048);
Thread tToF(osPriorityNormal,       2048);
Thread tAudio(osPriorityHigh,       4096);
Thread tHeartbeat(osPriorityLow,    2048);

// ─── Event Flags ─────────────────────────────────────────────────
EventFlags events;
#define EVT_MODE      0x01
#define EVT_REPEAT    0x02
#define EVT_SOS       0x04
#define EVT_FALL      0x08
#define EVT_CAPTURE   0x10
#define EVT_TOF_ALERT 0x20

Mutex httpMtx;
Mutex uartMtx;
Mutex dacMtx;

// Last ToF alert text (set by ToF thread, read by main/capture)
char gToFAlertText[64] = {0};

// ─── Forward Declarations ────────────────────────────────────────
void initEthernet();
void initArducam();
void initIMU();
void initVL53L0X();
void initDAC();

void taskCapture();
void taskIMU();
void taskToF();
void taskAudio();
void taskHeartbeat();

void cycleMode();
void onBtnMode();
void onBtnRepeat();
void onBtnSOSPress();
void onBtnSOSRelease();

// Camera
bool     camCapture(uint8_t* buf, uint32_t* len);
void     camWriteReg(uint8_t addr, uint8_t data);
uint8_t  camReadReg(uint8_t addr);
void     camWriteSensorReg(uint16_t reg, uint8_t val);
uint8_t  camReadSensorReg(uint16_t reg);
void     camSPISelect();
void     camSPIDeselect();

// ESP32 / UART
void     espSend(const char* msg);
bool     espReceiveAudio();

// VL53L0X
void     tofSetAddress(DigitalOut& xshut, uint8_t newAddr);
uint16_t tofReadDistance(uint8_t addr);

// IMU
float    imuGetMagnitude();

// DAC audio
void     playAudio(uint8_t* buf, uint32_t len);

// HTTP
bool     httpPost(const char* ep, const char* body = nullptr);
bool     httpGet(const char* ep, char* out, int outLen);

// Helpers
void     blinkLED(DigitalOut& led, int n, int ms);
void     setModeLED(Mode m);

// ================================================================
//  MAIN
// ================================================================
int main() {
    printf("\r\n================================================\r\n");
    printf("  AI Smart Assistive Glasses — K66F FINAL\r\n");
    printf("  MCUXpresso | mbed OS 6 | Cortex-M4F\r\n");
    printf("================================================\r\n");

    // Button interrupts
    btnMode.fall(callback(onBtnMode));
    btnRepeat.fall(callback(onBtnRepeat));
    btnSOS.fall(callback(onBtnSOSPress));
    btnSOS.rise(callback(onBtnSOSRelease));

    // Init all peripherals
    initEthernet();
    initArducam();
    initIMU();
    initVL53L0X();
    initDAC();

    setModeLED(gMode);
    blinkLED(ledGreen, 3, 200);
    printf("All hardware ready.\r\n\r\n");

    // Start threads
    tCapture.start(taskCapture);
    tIMU.start(taskIMU);
    tToF.start(taskToF);
    tAudio.start(taskAudio);
    tHeartbeat.start(taskHeartbeat);

    printf("Mode: %s — waiting for events.\r\n", MODE_LABELS[(int)gMode]);

    // ── Main event loop ──────────────────────────────────────────
    while (true) {
        uint32_t evt = events.wait_any(
            EVT_MODE | EVT_REPEAT | EVT_SOS |
            EVT_FALL | EVT_TOF_ALERT,
            osWaitForever
        );

        if (evt & EVT_MODE) {
            cycleMode();
        }

        if (evt & EVT_REPEAT) {
            if (gFallConfirm) {
                gFallConfirm = false;
                printf("Fall CANCELLED\r\n");
                httpPost("/event/cancel_fall");
                blinkLED(ledGreen, 2, 150);
            } else {
                // Ask server to re-queue last audio
                char resp[512];
                httpGet("/repeat", resp, sizeof(resp));
            }
        }

        if (evt & EVT_SOS) {
            printf("!!! SOS !!!\r\n");
            ledRed = 0;
            httpPost("/event/sos");
            ThisThread::sleep_for(3000ms);
            ledRed = 1;
        }

        if (evt & EVT_FALL) {
            printf("!!! FALL !!!\r\n");
            blinkLED(ledRed, 6, 100);
            httpPost("/event/fall");
            gFallConfirm   = true;
            gFallConfirmMs = Kernel::get_ms_count();
            ThisThread::sleep_for(FALL_CANCEL_MS);
            if (gFallConfirm) {
                gFallConfirm = false;
                printf("Fall escalated\r\n");
            }
        }

        if (evt & EVT_TOF_ALERT) {
            // ToF detected hazard — send emergency alert to server
            // so it generates speech, which audio task will fetch
            char body[128];
            snprintf(body, sizeof(body),
                     "{\"alert\":\"%s\"}", gToFAlertText);
            httpPost("/tof_alert", body);
        }
    }
}

// ================================================================
//  TASK: CAPTURE — triggers camera + ESP32 every 1s
// ================================================================
void taskCapture() {
    printf("Capture task started\r\n");

    // Wait for ESP32 to say it's ready
    char line[32] = {0};
    int  li = 0;
    while (true) {
        if (espUART.readable()) {
            char c = espUART.getc();
            if (c == '\n') {
                line[li] = 0;
                if (strstr(line, "READY")) {
                    gESP32Ready = true;
                    printf("ESP32 READY\r\n");
                    break;
                }
                li = 0;
            } else if (c != '\r' && li < 31) {
                line[li++] = c;
            }
        }
        ThisThread::sleep_for(50ms);
    }

    while (true) {
        if (gMode == Mode::OBJECT || gMode == Mode::TEXT) {

            // Step 1: Capture image from Arducam via SPI
            uint8_t  imgBuf[30000];  // 30KB — enough for 320x240 JPEG
            uint32_t imgLen = 0;

            bool captured = camCapture(imgBuf, &imgLen);

            if (captured && imgLen > 0) {
                printf("Image captured: %lu bytes\r\n", imgLen);

                uartMtx.lock();

                // Step 2: Tell ESP32 image is coming + size
                char header[32];
                snprintf(header, sizeof(header), "IMG:%lu\n", imgLen);
                espSend(header);
                ThisThread::sleep_for(30ms);  // ESP32 prep time

                // Step 3: Send raw image bytes to ESP32 via UART
                // ESP32 will upload to server
                for (uint32_t i = 0; i < imgLen; i++) {
                    espUART.putc(imgBuf[i]);
                }

                printf("Image sent to ESP32 (%lu bytes)\r\n", imgLen);

                // Step 4: Receive audio bytes back from ESP32
                bool gotAudio = espReceiveAudio();
                if (gotAudio && gAudioLen > 0) {
                    playAudio(gAudioBuf, gAudioLen);
                }

                uartMtx.unlock();
            } else {
                printf("Camera capture failed\r\n");
            }
        }

        ThisThread::sleep_for(CAPTURE_INTERVAL_MS);
    }
}

// ================================================================
//  TASK: IMU — 100Hz fall detection
// ================================================================
void taskIMU() {
    printf("IMU task started @ 100Hz\r\n");

    while (true) {
        float mag = imuGetMagnitude();

        if (!gFallPhase1) {
            if (mag < FALL_FREEFALL_G) {
                gFallPhase1   = true;
                gFallPhase1Ms = Kernel::get_ms_count();
            }
        } else {
            uint32_t elapsed = Kernel::get_ms_count() - gFallPhase1Ms;
            if (mag >= FALL_FREEFALL_G) {
                if (elapsed >= FALL_FREEFALL_MS) {
                    // Phase 1 confirmed — watch for impact
                    uint32_t t0 = Kernel::get_ms_count();
                    while ((Kernel::get_ms_count() - t0) < FALL_IMPACT_WIN_MS) {
                        if (imuGetMagnitude() >= FALL_IMPACT_G) {
                            events.set(EVT_FALL);
                            break;
                        }
                        ThisThread::sleep_for(IMU_SAMPLE_MS);
                    }
                }
                gFallPhase1 = false;
            }
        }
        ThisThread::sleep_for(IMU_SAMPLE_MS);
    }
}

// ================================================================
//  TASK: ToF — 20Hz distance monitoring on all 4 sensors
// ================================================================
void taskToF() {
    printf("ToF task started @ 20Hz\r\n");

    // Cooldown per direction to avoid spam
    uint32_t lastAlert[4] = {0, 0, 0, 0};
    const uint32_t TOF_COOLDOWN_MS = 4000;  // 4s between same-direction alerts

    while (true) {
        uint32_t now = Kernel::get_ms_count();

        uint16_t dFwd = tofReadDistance(TOF_ADDR_FWD);
        uint16_t dDwn = tofReadDistance(TOF_ADDR_DWN);
        uint16_t dLft = tofReadDistance(TOF_ADDR_LFT);
        uint16_t dRgt = tofReadDistance(TOF_ADDR_RGT);

        // ── Downward sensor — stair / drop-off ──
        // If floor drops away suddenly → stairs
        if (dDwn > TOF_STAIR_MM && (now - lastAlert[1]) > TOF_COOLDOWN_MS) {
            snprintf(gToFAlertText, sizeof(gToFAlertText),
                     "Warning! Stairs or drop ahead.");
            lastAlert[1] = now;
            events.set(EVT_TOF_ALERT);
            printf("ToF-DOWN: %dmm — STAIR ALERT\r\n", dDwn);
        }

        // ── Forward sensor — obstacle ──
        if (dFwd > 0 && dFwd < TOF_OBSTACLE_MM
            && (now - lastAlert[0]) > TOF_COOLDOWN_MS) {
            snprintf(gToFAlertText, sizeof(gToFAlertText),
                     "Obstacle ahead, %d centimeters.", dFwd / 10);
            lastAlert[0] = now;
            events.set(EVT_TOF_ALERT);
            printf("ToF-FWD: %dmm — OBSTACLE\r\n", dFwd);
        }

        // ── Left sensor — side clearance ──
        if (dLft > 0 && dLft < TOF_SIDE_MM
            && (now - lastAlert[2]) > TOF_COOLDOWN_MS) {
            snprintf(gToFAlertText, sizeof(gToFAlertText),
                     "Wall or object on your left.");
            lastAlert[2] = now;
            events.set(EVT_TOF_ALERT);
            printf("ToF-LEFT: %dmm — SIDE ALERT\r\n", dLft);
        }

        // ── Right sensor — side clearance ──
        if (dRgt > 0 && dRgt < TOF_SIDE_MM
            && (now - lastAlert[3]) > TOF_COOLDOWN_MS) {
            snprintf(gToFAlertText, sizeof(gToFAlertText),
                     "Wall or object on your right.");
            lastAlert[3] = now;
            events.set(EVT_TOF_ALERT);
            printf("ToF-RIGHT: %dmm — SIDE ALERT\r\n", dRgt);
        }

        ThisThread::sleep_for(TOF_SAMPLE_MS);
    }
}

// ================================================================
//  TASK: AUDIO — polls server for pending audio clips
// ================================================================
void taskAudio() {
    printf("Audio task started\r\n");

    while (true) {
        // Poll /audio/next — server queues audio for ToF alerts, mode changes, etc.
        char resp[MAX_AUDIO_BYTES];
        bool got = httpGet("/audio/next", resp, sizeof(resp));

        if (got) {
            // Parse Content-Length and strip HTTP header
            char* body = strstr(resp, "\r\n\r\n");
            if (body) {
                body += 4;
                int bodyLen = strlen(body);
                if (bodyLen > 44) {
                    playAudio((uint8_t*)body, bodyLen);
                }
            }
        }

        ThisThread::sleep_for(500ms);
    }
}

// ================================================================
//  TASK: HEARTBEAT — server keepalive
// ================================================================
void taskHeartbeat() {
    while (true) {
        char resp[256];
        bool alive = httpGet("/status", resp, sizeof(resp));
        ledBlue = alive ? !ledBlue : 0;
        if (!alive) printf("Server unreachable\r\n");
        ThisThread::sleep_for(HEARTBEAT_MS);
    }
}

// ================================================================
//  ARDUCAM OV2640 — SPI Camera
// ================================================================
void camSPISelect()   { camCS = 0; }
void camSPIDeselect() { camCS = 1; }

// Write to Arducam SPI register
void camWriteReg(uint8_t addr, uint8_t data) {
    camSPISelect();
    camSPI.write(addr | 0x80);  // Write bit = MSB set
    camSPI.write(data);
    camSPIDeselect();
}

// Read from Arducam SPI register
uint8_t camReadReg(uint8_t addr) {
    camSPISelect();
    camSPI.write(addr & 0x7F);  // Read bit = MSB clear
    uint8_t val = camSPI.write(0x00);
    camSPIDeselect();
    return val;
}

// Write to OV2640 sensor register via I2C
void camWriteSensorReg(uint16_t reg, uint8_t val) {
    char buf[2] = { (char)reg, (char)val };
    camI2C.write(OV2640_I2C_ADDR << 1, buf, 2);
}

void initArducam() {
    printf("Arducam OV2640 init... ");

    camSPI.frequency(4000000);  // 4 MHz SPI
    camSPI.format(8, 0);        // 8-bit, mode 0
    camSPIDeselect();
    ThisThread::sleep_for(100ms);

    // Test SPI comms — write/read test register
    camWriteReg(ARDUCHIP_TEST1, 0x55);
    uint8_t test = camReadReg(ARDUCHIP_TEST1);
    if (test != 0x55) {
        printf("FAILED (SPI test got 0x%02X)\r\n", test);
        return;
    }

    // Reset CPLD
    camWriteReg(0x07, 0x80);
    ThisThread::sleep_for(100ms);
    camWriteReg(0x07, 0x00);
    ThisThread::sleep_for(100ms);

    // Set JPEG format, 320x240
    camWriteSensorReg(0xFF, 0x01);  // Select bank 1
    camWriteSensorReg(0x12, 0x80);  // Reset sensor
    ThisThread::sleep_for(100ms);

    // JPEG mode
    camWriteSensorReg(0xFF, 0x00);
    camWriteSensorReg(0xDA, 0x10);  // JPEG output
    camWriteSensorReg(0xD7, 0x03);

    // Resolution QVGA 320x240
    camWriteSensorReg(0xFF, 0x00);
    camWriteSensorReg(0xE0, 0x04);
    camWriteSensorReg(0xC0, 0x64);
    camWriteSensorReg(0xC1, 0x4B);
    camWriteSensorReg(0x8C, 0x00);
    camWriteSensorReg(0x86, 0x3D);
    camWriteSensorReg(0x50, 0x00);
    camWriteSensorReg(0x51, 0xC8);
    camWriteSensorReg(0x52, 0x96);
    camWriteSensorReg(0x53, 0x00);
    camWriteSensorReg(0x54, 0x00);
    camWriteSensorReg(0x55, 0x00);
    camWriteSensorReg(0x57, 0x00);
    camWriteSensorReg(0x5A, 0x50);
    camWriteSensorReg(0x5B, 0x3C);
    camWriteSensorReg(0x5C, 0x00);
    camWriteSensorReg(0xE0, 0x00);

    printf("OK\r\n");
}

bool camCapture(uint8_t* buf, uint32_t* outLen) {
    // Clear FIFO
    camWriteReg(ARDUCHIP_FIFO, FIFO_CLEAR_MASK);
    ThisThread::sleep_for(10ms);

    // Start capture
    camWriteReg(ARDUCHIP_FIFO, FIFO_START_MASK);

    // Wait for capture done (max 2 seconds)
    uint32_t t0 = Kernel::get_ms_count();
    while (!(camReadReg(ARDUCHIP_TRIG) & CAP_DONE_MASK)) {
        if ((Kernel::get_ms_count() - t0) > 2000) {
            printf("Camera capture timeout\r\n");
            return false;
        }
        ThisThread::sleep_for(5ms);
    }

    // Read FIFO size (3 bytes)
    uint32_t len = ((uint32_t)camReadReg(FIFO_SIZE3) << 16)
                 | ((uint32_t)camReadReg(FIFO_SIZE2) << 8)
                 |  (uint32_t)camReadReg(FIFO_SIZE1);

    if (len == 0 || len > 30000) {
        printf("Bad FIFO size: %lu\r\n", len);
        return false;
    }

    // Burst read from FIFO
    camSPISelect();
    camSPI.write(BURST_FIFO_READ);
    for (uint32_t i = 0; i < len; i++) {
        buf[i] = camSPI.write(0x00);
    }
    camSPIDeselect();

    *outLen = len;
    return true;
}

// ================================================================
//  VL53L0X — Time-of-Flight Distance Sensors
// ================================================================
void tofSetAddress(DigitalOut& xshut, uint8_t newAddr) {
    // Enable only this sensor (others stay in shutdown)
    xshut = 1;
    ThisThread::sleep_for(10ms);

    // Write new I2C address to VL53L0X register 0x8A
    char cmd[2] = { (char)0x8A, (char)(newAddr << 1) };
    sensI2C.write(TOF_DEFAULT << 1, cmd, 2);
    ThisThread::sleep_for(10ms);

    printf("ToF sensor reassigned to 0x%02X\r\n", newAddr);
}

void initVL53L0X() {
    printf("VL53L0X init... ");

    // All sensors start in shutdown (XSHUT = LOW)
    xshutFwd = 0; xshutDwn = 0;
    xshutLft = 0; xshutRgt = 0;
    ThisThread::sleep_for(20ms);

    // Enable and reassign each sensor one at a time
    tofSetAddress(xshutFwd, TOF_ADDR_FWD);
    tofSetAddress(xshutDwn, TOF_ADDR_DWN);
    tofSetAddress(xshutLft, TOF_ADDR_LFT);
    tofSetAddress(xshutRgt, TOF_ADDR_RGT);

    // Init each sensor — set continuous measurement mode
    uint8_t addrs[4] = { TOF_ADDR_FWD, TOF_ADDR_DWN,
                         TOF_ADDR_LFT, TOF_ADDR_RGT };
    for (int i = 0; i < 4; i++) {
        // Start continuous ranging, 50ms period
        char cmd[2] = { (char)0x80, (char)0x01 };
        sensI2C.write(addrs[i] << 1, cmd, 2);
        cmd[0] = 0xFF; cmd[1] = 0x01;
        sensI2C.write(addrs[i] << 1, cmd, 2);
        cmd[0] = 0x00; cmd[1] = 0x00;
        sensI2C.write(addrs[i] << 1, cmd, 2);
        cmd[0] = 0xFF; cmd[1] = 0x00;
        sensI2C.write(addrs[i] << 1, cmd, 2);
        // Start continuous back-to-back mode
        cmd[0] = 0x00; cmd[1] = 0x02;
        sensI2C.write(addrs[i] << 1, cmd, 2);
    }

    printf("OK — 4 sensors active\r\n");
}

uint16_t tofReadDistance(uint8_t addr) {
    // Read result range status + distance from VL53L0X result register
    char reg = 0x14;  // RESULT_RANGE_STATUS
    char data[12] = {0};

    sensI2C.write(addr << 1, &reg, 1, true);
    sensI2C.read(addr << 1, data, 12);

    // Bytes 10-11 = range in mm
    uint16_t dist = ((uint16_t)data[10] << 8) | (uint16_t)data[11];
    return dist;
}

// ================================================================
//  MPU6050 IMU
// ================================================================
void initIMU() {
    printf("MPU6050 init... ");
    char cmd[2];

    cmd[0] = 0x6B; cmd[1] = 0x00;  // Wake up
    sensI2C.write(0x68 << 1, cmd, 2);
    ThisThread::sleep_for(10ms);

    cmd[0] = 0x1C; cmd[1] = 0x10;  // Accel ±8g
    sensI2C.write(0x68 << 1, cmd, 2);

    cmd[0] = 0x19; cmd[1] = 9;     // 100 Hz sample rate
    sensI2C.write(0x68 << 1, cmd, 2);

    printf("OK\r\n");
}

float imuGetMagnitude() {
    char reg = 0x3B;
    char raw[6];
    sensI2C.write(0x68 << 1, &reg, 1, true);
    sensI2C.read(0x68 << 1, raw, 6);

    int16_t ax = (int16_t)((raw[0] << 8) | raw[1]);
    int16_t ay = (int16_t)((raw[2] << 8) | raw[3]);
    int16_t az = (int16_t)((raw[4] << 8) | raw[5]);

    float gx = ax / 4096.0f;
    float gy = ay / 4096.0f;
    float gz = az / 4096.0f;
    return sqrtf(gx*gx + gy*gy + gz*gz);
}

// ================================================================
//  DAC AUDIO — PAM8403 Analog Amplifier
// ================================================================
void initDAC() {
    printf("DAC (PAM8403)... ");
    // Set DAC to midpoint (silence = 0.5 = 1.65V for 3.3V ref)
    dacOut.write(0.5f);
    printf("OK\r\n");
}

void playAudio(uint8_t* buf, uint32_t len) {
    if (len <= 44) return;

    // Skip 44-byte WAV header
    int16_t* pcm     = (int16_t*)(buf + 44);
    uint32_t samples = (len - 44) / 2;

    printf("Playing %lu samples @ %dHz via DAC\r\n", samples, AUDIO_SAMPLE_RATE);

    dacMtx.lock();

    // Output each 16-bit PCM sample via DAC
    // PCM range: -32768 to +32767
    // DAC range: 0.0f to 1.0f
    // Map: sample → (sample + 32768) / 65536.0f

    // Timing: 1 sample every 1/16000 = 62.5 µs
    // Use a tight loop with Timer for accuracy
    Timer t;
    for (uint32_t i = 0; i < samples; i++) {
        t.reset(); t.start();
        float normalized = ((float)pcm[i] + 32768.0f) / 65536.0f;
        dacOut.write(normalized);
        // Wait for next sample period (62.5 µs = 62500 ns)
        while (t.elapsed_time().count() < 62500) { /* spin */ }
        t.stop();
    }

    // Return to silence
    dacOut.write(0.5f);
    dacMtx.unlock();

    printf("Playback complete\r\n");
}

// ================================================================
//  ESP32 UART PROTOCOL
// ================================================================
void espSend(const char* msg) {
    espUART.printf("%s", msg);
}

bool espReceiveAudio() {
    // Wait for response header from ESP32
    char line[64] = {0};
    int  li = 0;

    uint32_t t0 = Kernel::get_ms_count();
    while ((Kernel::get_ms_count() - t0) < 10000) {
        if (espUART.readable()) {
            char c = espUART.getc();
            if (c == '\n') break;
            if (c != '\r' && li < 63) line[li++] = c;
        }
    }
    line[li] = 0;

    if (strcmp(line, "NO_AUDIO") == 0)    return false;
    if (strncmp(line, "ERROR:", 6) == 0) {
        printf("ESP32 error: %s\r\n", line + 6);
        return false;
    }

    if (strncmp(line, "AUDIO_START:", 12) == 0) {
        uint32_t audioLen = (uint32_t)atoi(line + 12);
        if (audioLen == 0 || audioLen > MAX_AUDIO_BYTES) return false;

        printf("Receiving %lu audio bytes...\r\n", audioLen);

        uint32_t received = 0;
        t0 = Kernel::get_ms_count();
        while (received < audioLen && (Kernel::get_ms_count() - t0) < 15000) {
            if (espUART.readable()) {
                gAudioBuf[received++] = espUART.getc();
            }
        }
        gAudioLen = received;

        // Read AUDIO_END marker
        char endLine[16] = {0};
        int eli = 0;
        t0 = Kernel::get_ms_count();
        while ((Kernel::get_ms_count() - t0) < 1000) {
            if (espUART.readable()) {
                char c = espUART.getc();
                if (c == '\n') break;
                if (c != '\r' && eli < 15) endLine[eli++] = c;
            }
        }

        printf("Got %lu bytes (marker: %s)\r\n", received, endLine);
        return received > 44;
    }
    return false;
}

// ================================================================
//  BUTTON CALLBACKS
// ================================================================
void onBtnMode() {
    static uint32_t last = 0;
    uint32_t now = Kernel::get_ms_count();
    if (now - last < 50) return;
    last = now;
    events.set(EVT_MODE);
}
void onBtnRepeat() {
    static uint32_t last = 0;
    uint32_t now = Kernel::get_ms_count();
    if (now - last < 50) return;
    last = now;
    events.set(EVT_REPEAT);
}
void onBtnSOSPress()   { gSOSActive = true;  gSOSPressMs = Kernel::get_ms_count(); }
void onBtnSOSRelease() {
    if (!gSOSActive) return;
    uint32_t held = Kernel::get_ms_count() - gSOSPressMs;
    gSOSActive = false;
    if (held >= SOS_HOLD_MS) events.set(EVT_SOS);
    else printf("SOS released early (%lums)\r\n", held);
}

void cycleMode() {
    gMode = (Mode)(((int)gMode + 1) % 3);
    printf("Mode → %s\r\n", MODE_LABELS[(int)gMode]);
    setModeLED(gMode);
    char body[48];
    snprintf(body, sizeof(body), "{\"mode\":\"%s\"}", MODE_NAMES[(int)gMode]);
    httpPost("/mode", body);
}

// ================================================================
//  ETHERNET + HTTP
// ================================================================
void initEthernet() {
    printf("Ethernet DHCP... ");
    eth.set_dhcp(true);
    if (eth.connect() != NSAPI_ERROR_OK) {
        printf("FAILED\r\n");
        return;
    }
    SocketAddress ip;
    eth.get_ip_address(&ip);
    printf("OK — %s\r\n", ip.get_ip_address());
}

bool httpPost(const char* ep, const char* body) {
    httpMtx.lock();
    bool ok = false;
    TCPSocket s; s.open(&eth); s.set_timeout(5000);
    SocketAddress a; eth.get_hostbyname(SERVER_IP, &a); a.set_port(SERVER_PORT);
    if (s.connect(a) == NSAPI_ERROR_OK) {
        char req[512];
        int blen = body ? strlen(body) : 0;
        snprintf(req, sizeof(req),
            "POST %s HTTP/1.1\r\nHost: %s:%d\r\n"
            "Content-Type: application/json\r\nContent-Length: %d\r\n"
            "Connection: close\r\n\r\n%s",
            ep, SERVER_IP, SERVER_PORT, blen, body ? body : "");
        s.send(req, strlen(req));
        char resp[128]; int n = s.recv(resp, 127);
        if (n > 0) { resp[n] = 0; ok = strstr(resp, "200") != nullptr; }
    }
    s.close(); httpMtx.unlock();
    return ok;
}

bool httpGet(const char* ep, char* out, int outLen) {
    httpMtx.lock();
    bool ok = false;
    TCPSocket s; s.open(&eth); s.set_timeout(5000);
    SocketAddress a; eth.get_hostbyname(SERVER_IP, &a); a.set_port(SERVER_PORT);
    if (s.connect(a) == NSAPI_ERROR_OK) {
        char req[256];
        snprintf(req, sizeof(req),
            "GET %s HTTP/1.1\r\nHost: %s:%d\r\nConnection: close\r\n\r\n",
            ep, SERVER_IP, SERVER_PORT);
        s.send(req, strlen(req));
        int total = 0, n;
        while ((n = s.recv(out + total, outLen - total - 1)) > 0) total += n;
        out[total] = 0;
        ok = total > 0 && !strstr(out, "404");
    }
    s.close(); httpMtx.unlock();
    return ok;
}

// ================================================================
//  HELPERS
// ================================================================
void blinkLED(DigitalOut& led, int n, int ms) {
    for (int i = 0; i < n; i++) {
        led = 0; ThisThread::sleep_for(ms);
        led = 1; ThisThread::sleep_for(ms);
    }
}
void setModeLED(Mode m) {
    ledGreen = (m == Mode::OBJECT) ? 0 : 1;
    ledBlue  = (m == Mode::TEXT)   ? 0 : 1;
}
