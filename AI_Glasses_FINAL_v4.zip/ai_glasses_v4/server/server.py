"""
================================================================
  AI SMART ASSISTIVE GLASSES — SERVER FINAL
  Windows | Python | FastAPI
================================================================
  New in this version:
  - POST /tof_alert  : handles real-time ToF distance alerts
    from K66F (obstacle, stair, side wall)
  - ToF alerts get emergency audio — bypass queue/mode
================================================================
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, JSONResponse
import uvicorn, cv2, numpy as np, pytesseract
import threading, time, uuid, os, base64, logging
from pathlib import Path
from pydantic import BaseModel
from typing import Optional
import openai

# ─── Windows Tesseract path ──────────────────────────────────────
pytesseract.pytesseract.tesseract_cmd = \
    r'C:\Program Files\Tesseract-OCR\tesseract.exe'

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler("server.log")]
)
log = logging.getLogger("glasses")

# ─── Config ──────────────────────────────────────────────────────
OPENAI_API_KEY    = "YOUR_OPENAI_API_KEY_HERE"   # ← paste your key
AUDIO_DIR         = Path("audio_cache")
YOLO_CONFIDENCE   = 0.60
OPENAI_THRESHOLD  = 0.45
COOLDOWN_SECS     = 8
OPENAI_RATE_LIMIT = 10
MAX_AUDIO_QUEUE   = 2
PORT              = 8080
AUDIO_DIR.mkdir(exist_ok=True)
openai.api_key = OPENAI_API_KEY

# ─── Object priority ─────────────────────────────────────────────
CRITICAL = {
    "stairs","step","curb","car","truck","bus","bicycle",
    "motorcycle","person","fire hydrant","stop sign","traffic light"
}
HIGH = {"door","chair","dining table","bench","dog","cat"}
# Everything else = suppressed in object mode

# ─── State ────────────────────────────────────────────────────────
class State:
    def __init__(self):
        self.mode           = "object"
        self.last_detection = "None"
        self.audio_queue    = []        # list of (audio_id, path)
        self.cooldowns      = {}
        self.last_openai    = 0
        self.fall_pending   = False
        self.sos_pending    = False
        self.lock           = threading.Lock()
        self.start_time     = time.time()
S = State()

# ─── TTS ─────────────────────────────────────────────────────────
tts_lock = threading.Lock()

def tts(text: str):
    try:
        with tts_lock:
            import pyttsx3
            aid    = str(uuid.uuid4())[:8]
            path   = AUDIO_DIR / f"audio_{aid}.wav"
            engine = pyttsx3.init()
            engine.setProperty("rate", 145)
            engine.setProperty("volume", 1.0)
            for v in engine.getProperty("voices"):
                if "zira" in v.name.lower() or "david" in v.name.lower():
                    engine.setProperty("voice", v.id)
                    break
            engine.save_to_file(text, str(path))
            engine.runAndWait()
            log.info(f"TTS: '{text}'")
            return str(path), aid
    except Exception as e:
        log.error(f"TTS: {e}")
        return None, None

def queue_audio(text: str) -> Optional[str]:
    path, aid = tts(text)
    if not path: return None
    with S.lock:
        if len(S.audio_queue) >= MAX_AUDIO_QUEUE:
            _, old = S.audio_queue.pop(0)
            try: os.remove(old)
            except: pass
        S.audio_queue.append((aid, path))
    return aid

def emergency_audio(text: str) -> str:
    """Front-of-queue, bypasses all limits and modes."""
    path, aid = tts(text)
    if path:
        with S.lock:
            S.audio_queue.insert(0, (aid, path))
    return aid or ""

# ─── YOLO ─────────────────────────────────────────────────────────
log.info("Loading YOLOv8n...")
from ultralytics import YOLO
yolo = YOLO("yolov8n.pt")
log.info("YOLOv8n ready ✓")

def run_yolo(frame):
    results = yolo(frame, conf=YOLO_CONFIDENCE, verbose=False)
    detections, max_conf, alert_text, should_alert = [], 0.0, "", False
    for r in results:
        for box in r.boxes:
            name = yolo.names[int(box.cls[0])].lower()
            conf = float(box.conf[0])
            max_conf = max(max_conf, conf)
            detections.append({"class": name, "confidence": round(conf, 2)})
            now = time.time()
            if name in CRITICAL:
                alert_text, should_alert = f"Warning! {name} detected ahead.", True
            elif name in HIGH:
                if now - S.cooldowns.get(name, 0) > COOLDOWN_SECS:
                    alert_text, should_alert = f"{name.capitalize()} nearby.", True
                    S.cooldowns[name] = now
    return {"detections": detections, "max_confidence": max_conf,
            "should_alert": should_alert, "alert_text": alert_text}

# ─── OpenAI Vision ────────────────────────────────────────────────
def run_vision(frame) -> str:
    if time.time() - S.last_openai < OPENAI_RATE_LIMIT: return ""
    try:
        S.last_openai = time.time()
        _, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
        b64    = base64.b64encode(buf).decode()
        resp   = openai.chat.completions.create(
            model="gpt-4o", max_tokens=80,
            messages=[{"role":"user","content":[
                {"type":"text","text":
                    "You are an assistive AI for a visually impaired user. "
                    "Describe this scene in 1-2 sentences. Mention hazards first."},
                {"type":"image_url","image_url":{
                    "url": f"data:image/jpeg;base64,{b64}", "detail":"low"}}
            ]}])
        return resp.choices[0].message.content.strip()
    except Exception as e:
        log.error(f"Vision: {e}")
        return "Could not analyze the scene."

# ─── OCR ──────────────────────────────────────────────────────────
def run_ocr(frame) -> str:
    try:
        gray   = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        thresh = cv2.adaptiveThreshold(gray, 255,
                    cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        coords = np.column_stack(np.where(thresh > 0))
        if len(coords) > 0:
            angle = cv2.minAreaRect(coords)[-1]
            angle = -(90 + angle) if angle < -45 else -angle
            if abs(angle) > 0.5:
                h, w = thresh.shape[:2]
                M = cv2.getRotationMatrix2D((w//2, h//2), angle, 1.0)
                thresh = cv2.warpAffine(thresh, M, (w, h),
                            flags=cv2.INTER_CUBIC,
                            borderMode=cv2.BORDER_REPLICATE)
        data  = pytesseract.image_to_data(thresh,
                    output_type=pytesseract.Output.DICT, config="--psm 6")
        words, total_conf, count = [], 0, 0
        for i, word in enumerate(data["text"]):
            conf = int(data["conf"][i])
            if conf > 50 and word.strip():
                words.append(word); total_conf += conf; count += 1
        avg_conf = total_conf / count if count else 0
        text = " ".join(words).strip()
        if not text or avg_conf < 60:
            return run_vision(frame) or "No text found."
        return f"Text reads: {text}"
    except Exception as e:
        log.error(f"OCR: {e}")
        return run_vision(frame) or "Could not read text."

# ─── App ──────────────────────────────────────────────────────────
app = FastAPI(title="AI Glasses Server FINAL", version="3.0")

@app.post("/frame")
async def frame(file: UploadFile = File(...)):
    data  = await file.read()
    frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if frame is None: raise HTTPException(400, "Bad image")
    log.info(f"Frame {frame.shape} | mode={S.mode}")

    if S.mode == "quiet":
        return JSONResponse({"status":"quiet","audio_id":None})

    if S.mode == "text":
        result = run_ocr(frame)
        aid    = queue_audio(result)
        S.last_detection = result
        return JSONResponse({"status":"ocr","result":result,"audio_id":aid})

    res = run_yolo(frame)
    if res["max_confidence"] < OPENAI_THRESHOLD and res["max_confidence"] > 0:
        desc = run_vision(frame)
        if desc:
            aid = queue_audio(desc)
            S.last_detection = desc
            return JSONResponse({"status":"vision","result":desc,"audio_id":aid})

    if res["should_alert"]:
        aid = queue_audio(res["alert_text"])
        S.last_detection = res["alert_text"]
        return JSONResponse({"status":"alert","detections":res["detections"],
                             "alert_text":res["alert_text"],"audio_id":aid})

    return JSONResponse({"status":"no_alert","detections":res["detections"],
                         "audio_id":None})

@app.post("/describe")
async def describe(file: UploadFile = File(...)):
    data  = await file.read()
    frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if frame is None: raise HTTPException(400, "Bad image")
    desc = run_vision(frame) or "Could not describe scene."
    aid  = queue_audio(desc)
    S.last_detection = desc
    return JSONResponse({"status":"described","result":desc,"audio_id":aid})

# ─── NEW: ToF alert endpoint ─────────────────────────────────────
class ToFAlert(BaseModel):
    alert: str   # e.g. "Warning! Stairs or drop ahead."

@app.post("/tof_alert")
async def tof_alert(req: ToFAlert):
    """
    Called by K66F when a VL53L0X sensor triggers a distance alert.
    Always emergency audio — bypasses mode and queue limits.
    Forward, downward, left, or right alert text.
    """
    log.warning(f"ToF ALERT: {req.alert}")
    aid = emergency_audio(req.alert)
    S.last_detection = req.alert
    return JSONResponse({"status":"tof_alert","alert":req.alert,"audio_id":aid})

class ModeReq(BaseModel):
    mode: str

@app.post("/mode")
async def set_mode(req: ModeReq):
    if req.mode not in {"object","text","quiet","sos"}:
        raise HTTPException(400, "Invalid mode")
    S.mode = req.mode
    log.info(f"Mode → {S.mode}")
    confirmations = {
        "object": "Object detection mode.",
        "text":   "Text reading mode.",
        "quiet":  "Quiet mode. Emergency alerts still active.",
        "sos":    "S.O.S. mode activated."
    }
    aid = queue_audio(confirmations[req.mode])
    return JSONResponse({"status":"ok","mode":S.mode,"audio_id":aid})

@app.post("/event/fall")
async def fall():
    log.warning("FALL EVENT")
    S.fall_pending = True
    aid = emergency_audio("Fall detected. Are you okay? Press repeat to cancel.")
    log.warning(f"Fall @ {time.strftime('%Y-%m-%d %H:%M:%S')}")
    return JSONResponse({"status":"acknowledged","audio_id":aid,"ts":time.time()})

@app.post("/event/cancel_fall")
async def cancel_fall():
    S.fall_pending = False
    aid = queue_audio("Fall alert cancelled.")
    return JSONResponse({"status":"cancelled","audio_id":aid})

@app.post("/event/sos")
async def sos():
    log.warning("SOS EVENT")
    S.sos_pending = True
    aid = emergency_audio("S.O.S. triggered. Help is being notified.")
    log.warning(f"SOS @ {time.strftime('%Y-%m-%d %H:%M:%S')}")
    return JSONResponse({"status":"acknowledged","audio_id":aid,"ts":time.time()})

@app.get("/audio/next")
async def audio_next():
    with S.lock:
        if not S.audio_queue: raise HTTPException(404, "No audio")
        aid, path = S.audio_queue.pop(0)
    if not os.path.exists(path): raise HTTPException(404, "File missing")
    return FileResponse(path, media_type="audio/wav")

@app.get("/audio/{audio_id}")
async def audio_by_id(audio_id: str):
    path = AUDIO_DIR / f"audio_{audio_id}.wav"
    if not path.exists(): raise HTTPException(404, "Not found")
    return FileResponse(str(path), media_type="audio/wav")

@app.get("/repeat")
async def repeat():
    if S.last_detection and S.last_detection != "None":
        aid = queue_audio(f"Repeating: {S.last_detection}")
        return JSONResponse({"status":"queued","audio_id":aid})
    return JSONResponse({"status":"nothing_to_repeat"})

@app.get("/status")
async def status():
    uptime = int(time.time() - S.start_time)
    return JSONResponse({
        "status":         "online",
        "mode":           S.mode,
        "last_detection": S.last_detection,
        "audio_queued":   len(S.audio_queue),
        "fall_pending":   S.fall_pending,
        "sos_pending":    S.sos_pending,
        "uptime":         f"{uptime//3600}h {(uptime%3600)//60}m {uptime%60}s"
    })

if __name__ == "__main__":
    log.info("=" * 50)
    log.info("  AI Smart Assistive Glasses — Server FINAL")
    log.info(f"  http://0.0.0.0:{PORT}")
    log.info("=" * 50)
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="info")
