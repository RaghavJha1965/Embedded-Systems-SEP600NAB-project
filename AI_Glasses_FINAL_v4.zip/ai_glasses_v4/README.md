# AI Smart Assistive Glasses — FINAL Setup Guide
## All Components | MCUXpresso | Windows

---

## COMPLETE COMPONENT LIST

| Component | Role | Interface |
|---|---|---|
| FRDM-K66F | Master controller | — |
| Arducam OV2640 | Camera capture | SPI + I2C |
| ESP32-CAM | Wi-Fi bridge only | UART |
| MPU6050 | Fall detection IMU | I2C |
| VL53L0X ×4 | Distance / hazard sensors | I2C |
| PAM8403 | Audio amplifier | Analog (DAC) |
| 8Ω speaker | Audio output | — |
| 3× Buttons | Mode / Repeat / SOS | GPIO |

---

## FULL WIRING DIAGRAM

### 1. UART — K66F ↔ ESP32-CAM
```
K66F D1 / PTD3 (TX)  ──────────►  ESP32-CAM U0R / GPIO3 (RX)
K66F D0 / PTD2 (RX)  ◄──────────  ESP32-CAM U0T / GPIO1 (TX)
K66F GND             ────────────  ESP32-CAM GND
```
⚠️ Disconnect these 2 wires before flashing ESP32-CAM. Reconnect after.

---

### 2. SPI — K66F ↔ Arducam OV2640 (SPI2 — PTB20-23)
```
K66F PTB20 (SPI2 MOSI)  ──────►  Arducam MOSI
K66F PTB22 (SPI2 MISO)  ◄──────  Arducam MISO
K66F PTB21 (SPI2 SCK)   ──────►  Arducam SCK
K66F PTB23 (SPI2 CS)    ──────►  Arducam CS
K66F 3.3V               ──────►  Arducam VCC
K66F GND                ──────►  Arducam GND
```
Also I2C for camera register config (separate I2C1 bus):
```
K66F PTE25 / D14 (SDA)  ──────►  Arducam SDA
K66F PTE24 / D15 (SCL)  ──────►  Arducam SCL
```
**Why SPI2?** SPI0 lives on PTD0–PTD3 which directly conflicts with our
UART pins (PTD2=RX, PTD3=TX). SPI2 on PTB20–23 has zero overlap
with UART, I2C0 (PTB0/1), or XSHUT (PTD4–7).

---

### 3. I2C Shared Bus — K66F ↔ MPU6050 + all 4 VL53L0X sensors
All devices share the same I2C0 bus (PTB1/PTB0):
```
K66F PTB1 / A4 (SDA)  ─────────────────────────────────────────
K66F PTB0 / A5 (SCL)  ─────────────────────────────────────────
                       │            │           │           │
                    MPU6050     VL53L0X-FWD  VL53L0X-DWN  VL53L0X-LFT  VL53L0X-RGT
                    (0x68)      (→0x30)      (→0x31)      (→0x32)      (→0x33)
```
Power all: VCC → 3.3V, GND → GND

MPU6050: tie AD0 → GND (sets address 0x68)

#### VL53L0X XSHUT pins (PTD4–PTD7 as specified):
```
VL53L0X FORWARD  XSHUT  →  K66F PTD4
VL53L0X DOWNWARD XSHUT  →  K66F PTD5
VL53L0X LEFT     XSHUT  →  K66F PTD6
VL53L0X RIGHT    XSHUT  →  K66F PTD7
```
K66F pulls these LOW at boot (all sensors off), then brings them HIGH
one at a time to assign each sensor a unique I2C address.

#### Sensor placement on glasses frame:
```
FORWARD  → front center, horizontal, pointing ahead
DOWNWARD → front bottom, angled ~30° downward (detects stairs)
LEFT     → left side, pointing left
RIGHT    → right side, pointing right
```

---

### 4. DAC → PAM8403 → Speaker
```
K66F PTE30 (DAC0_OUT)  ──────►  PAM8403 Left IN+
K66F GND               ──────►  PAM8403 Left IN-  (tie to GND for mono)
K66F 5V (USB VBUS)     ──────►  PAM8403 VDD        ← needs 5V not 3.3V!
K66F GND               ──────►  PAM8403 GND
PAM8403 Left OUT+      ──────►  Speaker +
PAM8403 Left OUT-      ──────►  Speaker -
```
⚠️ PAM8403 requires 2.5–5V supply. Use K66F 5V pin (from USB).
⚠️ For mono: tie Right IN+ and Right IN- both to GND.
⚠️ The PAM8403 has two channels — only use Left channel.

---

### 5. Buttons (10KΩ pull-up resistors on each)
```
         3.3V
          │
         10KΩ
          │
K66F pin ─┤─── Button ─── GND

Mode   button  →  K66F PTA1
Repeat button  →  K66F PTA2
SOS    button  →  K66F PTD0
```

---

### 6. Ethernet
```
K66F RJ45  ──── Ethernet cable ──── Home router/switch
Laptop     ──── Same router (Wi-Fi or cable)
ESP32-CAM  ──── Same router (Wi-Fi)
```
All 3 devices MUST be on the same network.

---

## COMPONENT COMPARISON — What Changed

| | Old | New | Why |
|---|---|---|---|
| Camera | ESP32-CAM built-in | Arducam OV2640 via SPI | K66F controls capture |
| Amplifier | MAX98357A (I2S) | PAM8403 (analog) | Simpler, no digital audio |
| Audio interface | I2S digital | DAC analog | PAM8403 needs analog in |
| Distance sensing | YOLO only | VL53L0X ×4 + YOLO | Real-time, no AI needed |

---

## PAM8403 Notes

- Input: analog, 0–3.3V range from K66F DAC
- The K66F DAC maps PCM audio: silence = 1.65V (midpoint), peaks swing ±1.65V
- Volume: adjust via PAM8403 potentiometer if your board has one
- Output power: up to 3W into 4Ω with 5V supply
- If you hear distortion: lower DAC output range in `playAudio()` slightly

---

## VL53L0X Notes

- All 4 sensors ship with the SAME I2C address (0x29)
- The K66F reassigns them at boot using XSHUT pins
- After reassignment: Forward=0x30, Downward=0x31, Left=0x32, Right=0x33
- Max range: ~2m indoor, ~1.2m in bright light
- Distance thresholds (adjustable in main.cpp):
  - Forward obstacle: < 600mm → alert
  - Downward stair:   > 400mm drop → alert
  - Side walls:       < 300mm → alert

---

## MCUXpresso Setup

### 1. Create new SDK project
1. Open MCUXpresso IDE
2. File → New → Create a new C/C++ project
3. Select board: **FRDM-K66F**
4. Select SDK
5. Project type: **mbed OS** or bare-metal with SDK drivers

### 2. Add source files
- Copy `k66f/source/main.cpp` into your project `source/` folder
- Copy `k66f/mbed_app.json` into project root

### 3. Add mbed OS library
In MCUXpresso terminal:
```bash
mbed add https://github.com/ARMmbed/mbed-os
```

### 4. Change server IP
In `main.cpp` line ~55:
```cpp
#define SERVER_IP    "192.168.1.100"   // ← your laptop IP
```

### 5. Build + Flash
- Build: Project → Build All
- Flash: right-click project → Debug As → MCUXpresso IDE LinkServer

---

## Python Server Setup (Windows)

```cmd
cd server\
pip install -r requirements.txt
```

Install Tesseract:
https://github.com/UB-Mannheim/tesseract/wiki

Open `server.py` — change line:
```python
OPENAI_API_KEY = "sk-..."
```

Open firewall:
```cmd
netsh advfirewall firewall add rule name="Glasses" dir=in action=allow protocol=TCP localport=8080
```

Run:
```cmd
python server.py
```

---

## Arduino IDE Setup (ESP32-CAM)

1. Install Arduino IDE 2.x from arduino.cc
2. Add ESP32 board support:
   File → Preferences → Additional Board URLs:
   `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
3. Tools → Board → AI Thinker ESP32-CAM
4. Edit firmware: change WIFI_SSID, WIFI_PASSWORD, SERVER_IP
5. ⚠️ Disconnect K66F UART wires before flashing
6. Flash → reconnect UART wires → press RESET

---

## Demo Script

**Object Mode:**
"K66F sends CAPTURE command to ESP32 via UART.
K66F takes photo via Arducam SPI.
K66F sends image to ESP32 via UART.
ESP32 uploads to server — YOLOv8n detects a chair.
Audio comes back to K66F, plays through PAM8403."
→ Hear: "Chair nearby"

**Stair Detection (ToF — no AI needed):**
"Point the downward VL53L0X at a step.
K66F detects floor drop past 400mm threshold.
Immediate alert — no server needed."
→ Hear: "Warning! Stairs or drop ahead."
→ Latency: < 100ms

**Obstacle Detection (ToF):**
"Walk toward a wall — forward sensor < 600mm."
→ Hear: "Obstacle ahead, 45 centimeters."

**Fall Detection:**
"Shake K66F sharply — two-phase algorithm triggers."
→ Hear: "Fall detected. Are you okay?"
→ Press Repeat → "Fall alert cancelled."

**SOS:**
"Hold SOS 3 seconds."
→ Hear: "S.O.S. triggered."

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Arducam SPI test fails | Check MOSI/MISO/SCK/CS wiring; try lower SPI freq (1MHz) |
| VL53L0X all read same | Check XSHUT wiring; boot order in initVL53L0X() |
| No audio from PAM8403 | Check 5V supply; check DAC pin PTE30; check IN+/IN- |
| ESP32 won't flash | Disconnect K66F UART wires first |
| Server can't receive frames | Windows Firewall → allow port 8080 |
| K66F Ethernet DHCP fails | Check cable; try static IP assignment |
